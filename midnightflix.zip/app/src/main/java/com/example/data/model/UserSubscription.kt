package com.example.data.model

enum class SubscriptionPlan(
    val title: String,
    val priceText: String,
    val qualityAllowed: VideoQuality,
    val downloadSpeedText: String,
    val features: List<String>
) {
    GUEST_FREE(
        title = "Free Guest",
        priceText = "₹0 / Free Forever",
        qualityAllowed = VideoQuality.P480,
        downloadSpeedText = "Standard Speed (480p Only)",
        features = listOf(
            "Unlimited 480p SD Streaming",
            "480p Standard Downloads",
            "Standard Audio",
            "Basic Catalog Access"
        )
    ),
    VIP_PRO(
        title = "VIP HD Pass",
        priceText = "₹99 / Month",
        qualityAllowed = VideoQuality.P720,
        downloadSpeedText = "High Speed (720p HD)",
        features = listOf(
            "Crystal Clear 720p HD Streaming",
            "Fast 720p HD Downloads",
            "Midnight Shows Early Access",
            "Dolby Stereo Audio",
            "Ad-Free Viewing"
        )
    ),
    VIP_ULTRA(
        title = "VIP Ultra Master",
        priceText = "₹199 / Month",
        qualityAllowed = VideoQuality.P1080,
        downloadSpeedText = "Ultra Max Speed (1080p & 4K)",
        features = listOf(
            "Ultra 1080p Full HD & 4K Cinema",
            "Unlimited 1080p Offline Downloads",
            "Full Midnight Shows Uncensored",
            "Dolby Atmos 5.1 Surround Sound",
            "Zero Ads & VIP Master Badge",
            "Priority Fast Server Connections"
        )
    )
}

data class UserProfile(
    val email: String = "bilalkhatri386@gmail.com",
    val username: String = "Bilal Khatri (Owner)",
    val isOwner: Boolean = true,
    val activePlan: SubscriptionPlan = SubscriptionPlan.VIP_ULTRA,
    val isVipActive: Boolean = true,
    val downloadedCount: Int = 0,
    val availableStorageGb: Double = 48.6,
    val usedStorageGb: Double = 3.2
) {
    /**
     * Checks if this user has access to stream/download at requested quality
     */
    fun canAccessQuality(quality: VideoQuality): Boolean {
        // Owner or VIP Ultra gets everything including 1080p & 4K
        if (isOwner || activePlan == SubscriptionPlan.VIP_ULTRA) return true
        if (activePlan == SubscriptionPlan.VIP_PRO) {
            return quality == VideoQuality.P480 || quality == VideoQuality.P720
        }
        // Free guest can only access 480p
        return quality.isFree
    }
}
