package com.example.data.repository

import com.example.data.model.SubscriptionPlan
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class UserRepository {

    // Default with owner premium enabled for user
    private val _userProfile = MutableStateFlow(
        UserProfile(
            email = "bilalkhatri386@gmail.com",
            username = "Bilal Khatri (VIP Master)",
            isOwner = true,
            activePlan = SubscriptionPlan.VIP_ULTRA,
            isVipActive = true,
            downloadedCount = 0,
            availableStorageGb = 58.4,
            usedStorageGb = 2.8
        )
    )
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    fun updatePlan(plan: SubscriptionPlan) {
        _userProfile.value = _userProfile.value.copy(
            activePlan = plan,
            isVipActive = plan != SubscriptionPlan.GUEST_FREE
        )
    }

    /**
     * Toggles between Owner Full VIP Master (for user) and Guest Mode (Free 480p, Paid 720p/1080p)
     * so user can test both perspectives.
     */
    fun toggleOwnerMode(enabled: Boolean) {
        if (enabled) {
            _userProfile.value = _userProfile.value.copy(
                isOwner = true,
                activePlan = SubscriptionPlan.VIP_ULTRA,
                isVipActive = true,
                username = "Bilal Khatri (VIP Master)"
            )
        } else {
            _userProfile.value = _userProfile.value.copy(
                isOwner = false,
                activePlan = SubscriptionPlan.GUEST_FREE,
                isVipActive = false,
                username = "Guest User (Free 480p Mode)"
            )
        }
    }

    fun redeemVipCode(code: String): Boolean {
        val clean = code.trim().uppercase()
        if (clean == "VIP2026" || clean == "BILALVIP" || clean == "PREMIUM" || clean == "FREEVIP" || clean == "OWNER") {
            _userProfile.value = _userProfile.value.copy(
                activePlan = SubscriptionPlan.VIP_ULTRA,
                isVipActive = true,
                isOwner = true,
                username = "Bilal Khatri (VIP Master)"
            )
            return true
        } else if (clean == "PRO720" || clean == "HDVIP") {
            _userProfile.value = _userProfile.value.copy(
                activePlan = SubscriptionPlan.VIP_PRO,
                isVipActive = true,
                isOwner = false
            )
            return true
        }
        return false
    }
}
