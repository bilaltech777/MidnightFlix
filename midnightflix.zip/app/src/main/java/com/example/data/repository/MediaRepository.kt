package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.DownloadEntity
import com.example.data.local.DownloadState
import com.example.data.local.WatchHistoryEntity
import com.example.data.local.WatchlistEntity
import com.example.data.model.Episode
import com.example.data.model.MediaCategory
import com.example.data.model.MediaItem
import com.example.data.model.VideoQuality
import com.example.data.sample.CatalogData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

class MediaRepository(private val database: AppDatabase) {

    private val mediaDao = database.mediaDao()
    private val scope = CoroutineScope(Dispatchers.IO)
    private val activeDownloadJobs = ConcurrentHashMap<String, Job>()

    fun getAllMedia(): List<MediaItem> = CatalogData.allMediaItems

    fun getMediaById(id: String): MediaItem? {
        return CatalogData.allMediaItems.firstOrNull { it.id == id }
    }

    fun getMediaByCategory(category: MediaCategory): List<MediaItem> {
        if (category == MediaCategory.ALL) return CatalogData.allMediaItems
        return CatalogData.allMediaItems.filter { it.category == category }
    }

    fun getTrending(): List<MediaItem> {
        return CatalogData.allMediaItems.filter { it.isTrending }
    }

    fun getFeatured(): List<MediaItem> {
        return CatalogData.allMediaItems.filter { it.isFeatured }
    }

    fun getMidnightExclusives(): List<MediaItem> {
        return CatalogData.allMediaItems.filter { it.isMidnightExclusive || it.category == MediaCategory.MIDNIGHT }
    }

    fun searchMedia(query: String, category: MediaCategory? = null): List<MediaItem> {
        val q = query.trim().lowercase()
        return CatalogData.allMediaItems.filter { item ->
            val matchesCategory = category == null || category == MediaCategory.ALL || item.category == category
            val matchesQuery = q.isEmpty() ||
                    item.title.lowercase().contains(q) ||
                    item.hindiTitle.lowercase().contains(q) ||
                    item.genres.any { it.lowercase().contains(q) } ||
                    item.cast.any { it.lowercase().contains(q) }
            matchesCategory && matchesQuery
        }
    }

    // ==================== DOWNLOADS ====================
    val downloadsFlow: Flow<List<DownloadEntity>> = mediaDao.getAllDownloads().flowOn(Dispatchers.IO)

    suspend fun getDownload(id: String): DownloadEntity? = mediaDao.getDownloadById(id)

    fun startDownload(
        mediaItem: MediaItem,
        episode: Episode?,
        quality: VideoQuality
    ) {
        val downloadId = if (episode != null) "${mediaItem.id}_${episode.id}" else mediaItem.id
        val title = if (episode != null) "${mediaItem.title}: ${episode.title}" else mediaItem.title
        val subtitle = if (episode != null) "Season ${episode.seasonNumber} • Ep ${episode.episodeNumber} • ${quality.label}"
        else "${mediaItem.durationOrSeasons} • ${quality.label}"

        val totalSize = when (quality) {
            VideoQuality.P480 -> if (episode != null) 180 else 320
            VideoQuality.P720 -> if (episode != null) 420 else 750
            VideoQuality.P1080 -> if (episode != null) 890 else 1600
            VideoQuality.P4K -> if (episode != null) 1950 else 3800
        }

        val entity = DownloadEntity(
            id = downloadId,
            mediaId = mediaItem.id,
            episodeId = episode?.id,
            title = title,
            subtitle = subtitle,
            categoryName = mediaItem.category.displayName,
            quality = quality.label,
            totalSizeMb = totalSize,
            downloadedMb = 0f,
            progressPercent = 0,
            downloadSpeedText = "14.2 MB/s",
            status = DownloadState.DOWNLOADING,
            primaryColorHex = mediaItem.primaryColorHex,
            secondaryColorHex = mediaItem.secondaryColorHex
        )

        scope.launch {
            mediaDao.insertDownload(entity)
            simulateDownloadProgress(downloadId, totalSize)
        }
    }

    private fun simulateDownloadProgress(downloadId: String, totalSizeMb: Int) {
        activeDownloadJobs[downloadId]?.cancel()
        val job = scope.launch {
            var currentPercent = 0
            while (currentPercent < 100) {
                delay(400)
                currentPercent += (8..15).random()
                if (currentPercent > 100) currentPercent = 100

                val currentMb = (totalSizeMb * (currentPercent / 100f))
                val existing = mediaDao.getDownloadById(downloadId) ?: break

                if (existing.status == DownloadState.PAUSED) {
                    break
                }

                val updated = existing.copy(
                    progressPercent = currentPercent,
                    downloadedMb = currentMb,
                    status = if (currentPercent >= 100) DownloadState.COMPLETED else DownloadState.DOWNLOADING,
                    downloadSpeedText = if (currentPercent >= 100) "Completed" else "${(12..18).random()}.${(1..9).random()} MB/s"
                )
                mediaDao.updateDownload(updated)
            }
            activeDownloadJobs.remove(downloadId)
        }
        activeDownloadJobs[downloadId] = job
    }

    fun pauseDownload(id: String) {
        activeDownloadJobs[id]?.cancel()
        activeDownloadJobs.remove(id)
        scope.launch {
            val existing = mediaDao.getDownloadById(id) ?: return@launch
            mediaDao.updateDownload(existing.copy(status = DownloadState.PAUSED, downloadSpeedText = "Paused"))
        }
    }

    fun resumeDownload(id: String) {
        scope.launch {
            val existing = mediaDao.getDownloadById(id) ?: return@launch
            val updated = existing.copy(status = DownloadState.DOWNLOADING, downloadSpeedText = "Resuming...")
            mediaDao.updateDownload(updated)
            simulateDownloadProgress(id, existing.totalSizeMb)
        }
    }

    fun deleteDownload(id: String) {
        activeDownloadJobs[id]?.cancel()
        activeDownloadJobs.remove(id)
        scope.launch {
            mediaDao.deleteDownloadById(id)
        }
    }

    fun clearAllDownloads() {
        activeDownloadJobs.values.forEach { it.cancel() }
        activeDownloadJobs.clear()
        scope.launch {
            mediaDao.clearAllDownloads()
        }
    }

    // ==================== WATCH HISTORY ====================
    val watchHistoryFlow: Flow<List<WatchHistoryEntity>> = mediaDao.getWatchHistory().flowOn(Dispatchers.IO)

    fun saveWatchProgress(
        mediaItem: MediaItem,
        episode: Episode?,
        watchedSeconds: Long,
        totalSeconds: Long,
        quality: VideoQuality
    ) {
        val id = if (episode != null) "${mediaItem.id}_${episode.id}" else mediaItem.id
        val title = if (episode != null) "${mediaItem.title}: ${episode.title}" else mediaItem.title
        val subtitle = if (episode != null) "Season ${episode.seasonNumber} • Ep ${episode.episodeNumber}" else mediaItem.durationOrSeasons

        scope.launch {
            val entity = WatchHistoryEntity(
                id = id,
                mediaId = mediaItem.id,
                episodeId = episode?.id,
                title = title,
                subtitle = subtitle,
                categoryName = mediaItem.category.displayName,
                watchedSeconds = watchedSeconds,
                totalDurationSeconds = totalSeconds,
                lastQualityUsed = quality.label,
                primaryColorHex = mediaItem.primaryColorHex
            )
            mediaDao.saveWatchHistory(entity)
        }
    }

    suspend fun deleteWatchHistory(id: String) {
        mediaDao.deleteWatchHistoryById(id)
    }

    suspend fun clearWatchHistory() {
        mediaDao.clearAllWatchHistory()
    }

    // ==================== WATCHLIST ====================
    val watchlistFlow: Flow<List<WatchlistEntity>> = mediaDao.getWatchlist().flowOn(Dispatchers.IO)

    fun isInWatchlist(mediaId: String): Flow<Boolean> = mediaDao.isInWatchlist(mediaId)

    fun toggleWatchlist(mediaItem: MediaItem, isCurrentlyInList: Boolean) {
        scope.launch {
            if (isCurrentlyInList) {
                mediaDao.removeFromWatchlist(mediaItem.id)
            } else {
                mediaDao.addToWatchlist(
                    WatchlistEntity(
                        mediaId = mediaItem.id,
                        title = mediaItem.title,
                        categoryName = mediaItem.category.displayName,
                        rating = mediaItem.rating
                    )
                )
            }
        }
    }
}
