package com.example.data.model

enum class MediaCategory(val displayName: String, val badgeColorHex: Long) {
    ALL("All", 0xFFE50914),
    MOVIE("Movies", 0xFF00DFD8),
    ANIME("Anime", 0xFFFF007F),
    MIDNIGHT("Midnight Shows", 0xFF9D00FF),
    SERIES("Web Series", 0xFFFFB800)
}

enum class VideoQuality(
    val label: String,
    val resolutionText: String,
    val isFree: Boolean,
    val requiresVipTier: String,
    val badgeColorHex: Long,
    val estimatedSizePerEpisodeMb: Int
) {
    P480("480p", "Standard Definition (SD)", true, "Free for All", 0xFF00E676, 320),
    P720("720p", "High Definition (HD)", false, "Paid / VIP Pro", 0xFF2979FF, 750),
    P1080("1080p", "Full HD (FHD)", false, "Paid / VIP Ultra", 0xFFFF9100, 1600),
    P4K("4K", "Ultra HD HDR", false, "Paid / Master VIP", 0xFFFF0055, 3800)
}

data class Episode(
    val id: String,
    val mediaId: String,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val title: String,
    val durationMinutes: Int,
    val synopsis: String,
    val thumbnailGradientStartHex: Long = 0xFF1E1035,
    val thumbnailGradientEndHex: Long = 0xFF0A0A16,
    val videoStreamUrl: String = ""
)

data class MediaItem(
    val id: String,
    val title: String,
    val hindiTitle: String = "",
    val description: String,
    val category: MediaCategory,
    val genres: List<String>,
    val releaseYear: Int,
    val rating: Double,
    val durationOrSeasons: String,
    val isMidnightExclusive: Boolean = false,
    val isTrending: Boolean = false,
    val isFeatured: Boolean = false,
    val cast: List<String>,
    val audioLanguages: List<String> = listOf("Hindi", "English", "Japanese"),
    val subtitleLanguages: List<String> = listOf("English", "Hindi"),
    val episodes: List<Episode> = emptyList(),
    val primaryColorHex: Long = 0xFFE50914,
    val secondaryColorHex: Long = 0xFF7928CA,
    val trailerText: String = "Watch Official 4K Trailer",
    val videoStreamUrl: String = ""
) {
    fun getStreamUrl(episode: Episode? = null, quality: VideoQuality = VideoQuality.P480): String {
        if (episode != null && episode.videoStreamUrl.isNotBlank()) {
            return episode.videoStreamUrl
        }
        if (videoStreamUrl.isNotBlank()) {
            return videoStreamUrl
        }
        // Fallback reliable streams based on media/quality
        return when (quality) {
            VideoQuality.P480 -> "https://storage.googleapis.com/exoplayer-test-media-0/BigBuckBunny_320x180.mp4"
            VideoQuality.P720 -> "https://storage.googleapis.com/exoplayer-test-media-0/BigBuckBunny_320x180.mp4"
            VideoQuality.P1080 -> "https://storage.googleapis.com/exoplayer-test-media-0/BigBuckBunny_320x180.mp4"
            VideoQuality.P4K -> "https://storage.googleapis.com/exoplayer-test-media-0/BigBuckBunny_320x180.mp4"
        }
    }
}
