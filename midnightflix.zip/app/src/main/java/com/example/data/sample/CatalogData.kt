package com.example.data.sample

import com.example.data.model.Episode
import com.example.data.model.MediaCategory
import com.example.data.model.MediaItem

object CatalogData {

    val allMediaItems: List<MediaItem> = listOf(
        // ==================== MOVIES ====================
        MediaItem(
            id = "mov_01",
            title = "Shadow Protocol: Zero Hour",
            hindiTitle = "शैडो प्रोटोकॉल",
            description = "When a rogue cyber-operative threatens global power grids, an elite underground black-ops agent is pulled out of exile to execute an impossible covert counter-strike across 5 continents.",
            category = MediaCategory.MOVIE,
            genres = listOf("Action", "Sci-Fi", "Cyber-Thriller"),
            releaseYear = 2026,
            rating = 8.9,
            durationOrSeasons = "2h 24m",
            isTrending = true,
            isFeatured = true,
            cast = listOf("Vikram Rathore", "Elena Rostova", "Marcus Vance", "Kenji Sato"),
            primaryColorHex = 0xFFE50914,
            secondaryColorHex = 0xFF7928CA
        ),
        MediaItem(
            id = "mov_02",
            title = "Neon Tokyo 2099: Cyber Nexus",
            hindiTitle = "नियॉन टोक्यो २०९९",
            description = "In the rain-drenched neon alleys of 2099 Neo-Tokyo, a modified cyborg bounty hunter discovers a corporate conspiracy that threatens to rewrite human consciousness forever.",
            category = MediaCategory.MOVIE,
            genres = listOf("Sci-Fi", "Cyberpunk", "Neo-Noir"),
            releaseYear = 2025,
            rating = 9.1,
            durationOrSeasons = "2h 12m",
            isTrending = true,
            isFeatured = false,
            cast = listOf("Ren Takahashi", "Scarlett Cole", "Hidetoshi Nishida"),
            primaryColorHex = 0xFF00DFD8,
            secondaryColorHex = 0xFF7928CA
        ),
        MediaItem(
            id = "mov_03",
            title = "The Dark Knight of Mumbai",
            hindiTitle = "मुंबई का डार्क नाइट",
            description = "An undercover vigilante battles a sprawling crime syndicate controlling the underworld of Mumbai, sparking a high-stakes cat-and-mouse war on the streets.",
            category = MediaCategory.MOVIE,
            genres = listOf("Action", "Crime", "Thriller"),
            releaseYear = 2025,
            rating = 8.7,
            durationOrSeasons = "2h 38m",
            isTrending = false,
            isFeatured = true,
            cast = listOf("Kabir Khan", "Zoya Akhtar", "Manoj Bajpayee", "Nawazuddin"),
            primaryColorHex = 0xFFFF0055,
            secondaryColorHex = 0xFF0D0C1D
        ),
        MediaItem(
            id = "mov_04",
            title = "Interstellar Eclipse: Andromeda",
            hindiTitle = "इंटरस्टेलर ग्रहण",
            description = "Deep space expedition vessel Phoenix crosses a gravitational anomaly into an uncharted solar system harboring relics of an ancient Type-3 galactic civilization.",
            category = MediaCategory.MOVIE,
            genres = listOf("Sci-Fi", "Adventure", "Mystery"),
            releaseYear = 2026,
            rating = 9.3,
            durationOrSeasons = "2h 45m",
            isTrending = true,
            isFeatured = false,
            cast = listOf("David Corenswet", "Astrid Berges", "Matthew McConaughey"),
            primaryColorHex = 0xFF7928CA,
            secondaryColorHex = 0xFF00DFD8
        ),
        MediaItem(
            id = "mov_05",
            title = "Kalki 2898 Chronicle: The Avatar Rises",
            hindiTitle = "कल्कि २८९८ क्रॉनिकल",
            description = "In the dystopian city of Kasi in the year 2898, rebellion erupts against the Supreme God-King as prophecy foretells the birth of the final Avatar of Vishnu.",
            category = MediaCategory.MOVIE,
            genres = listOf("Mythology", "Action", "Epic Sci-Fi"),
            releaseYear = 2025,
            rating = 9.2,
            durationOrSeasons = "3h 02m",
            isTrending = true,
            isFeatured = true,
            cast = listOf("Prabhas", "Amitabh Bachchan", "Kamal Haasan", "Deepika Padukone"),
            primaryColorHex = 0xFFFFB800,
            secondaryColorHex = 0xFFE50914
        ),

        // ==================== ANIME ====================
        MediaItem(
            id = "ani_01",
            title = "Solo Leveling: Shadow Monarch Reign",
            hindiTitle = "सोलो लेवलिंग (हिंदी डब)",
            description = "Sung Jinwoo, the weakest hunter in all of mankind, awakens as the Sovereign of Shadows. As dimensional gates fracture the human realm, the Monarch of Shadows rises to conquer the world.",
            category = MediaCategory.ANIME,
            genres = listOf("Shonen", "Action", "Dark Fantasy", "Supernatural"),
            releaseYear = 2026,
            rating = 9.6,
            durationOrSeasons = "Season 2 • 12 Episodes",
            isTrending = true,
            isFeatured = true,
            cast = listOf("Taito Ban (Sung Jinwoo)", "Genta Nakamura", "Reina Ueda"),
            audioLanguages = listOf("Japanese", "Hindi Dub", "English Dub"),
            episodes = (1..12).map { ep ->
                Episode(
                    id = "ani_01_ep$ep",
                    mediaId = "ani_01",
                    seasonNumber = 2,
                    episodeNumber = ep,
                    title = when (ep) {
                        1 -> "Arise from Darkness"
                        2 -> "Red Gate Dungeon Massacre"
                        3 -> "The Demon Castle Trials"
                        4 -> "Commander of Undead Legions"
                        5 -> "National Level Hunter Awakening"
                        6 -> "Jeju Island S-Rank Raid"
                        7 -> "King of the Ant Colony"
                        8 -> "Shadow Extraction Supreme"
                        9 -> "Monarchs of Calamity"
                        10 -> "Ruler's Authority Unleashed"
                        11 -> "The Dragon King's Roar"
                        else -> "Monarch of Shadows Eternal"
                    },
                    durationMinutes = 24,
                    synopsis = "Jinwoo confronts dangerous dimensional gates and commands his undying shadow army."
                )
            },
            primaryColorHex = 0xFF7928CA,
            secondaryColorHex = 0xFF00DFD8
        ),
        MediaItem(
            id = "ani_02",
            title = "Jujutsu Kaisen: Cursed Realm Shinjuku",
            hindiTitle = "जुजुत्सु काइसेन (हिंदी डब)",
            description = "The ultimate clash between modern sorcery and the King of Curses Sukuna erupts in Shinjuku. Gojo Satoru and the sorcerers push their domain expansions past mortal limits.",
            category = MediaCategory.ANIME,
            genres = listOf("Action", "Supernatural", "Dark Fantasy"),
            releaseYear = 2026,
            rating = 9.5,
            durationOrSeasons = "Season 3 • 10 Episodes",
            isTrending = true,
            isFeatured = false,
            cast = listOf("Yuichi Nakamura (Gojo)", "Junya Enoki (Yuji)", "Junichi Suwabe (Sukuna)"),
            episodes = (1..10).map { ep ->
                Episode(
                    id = "ani_02_ep$ep",
                    mediaId = "ani_02",
                    seasonNumber = 3,
                    episodeNumber = ep,
                    title = "Episode $ep: Domain Clash in the Abyss",
                    durationMinutes = 23,
                    synopsis = "Infinite Void collides with Malevolent Shrine in the battle for Tokyo."
                )
            },
            primaryColorHex = 0xFFFF0055,
            secondaryColorHex = 0xFF1E1035
        ),
        MediaItem(
            id = "ani_03",
            title = "Demon Slayer: Infinity Castle Arc",
            hindiTitle = "डेमन स्लेयर",
            description = "Tanjiro, Nezuko, and the Hashira fall through the shifting dimensional walls of Muzan Kibutsuji's Infinity Castle for the final, bloody showdown against the Upper Moon demons.",
            category = MediaCategory.ANIME,
            genres = listOf("Action", "Fantasy", "Historical"),
            releaseYear = 2025,
            rating = 9.7,
            durationOrSeasons = "Movie Trilogy Part 1",
            isTrending = true,
            isFeatured = true,
            cast = listOf("Natsuki Hanae", "Akari Kito", "Hiro Shimono"),
            primaryColorHex = 0xFFE50914,
            secondaryColorHex = 0xFFFFB800
        ),
        MediaItem(
            id = "ani_04",
            title = "Chainsaw Man: Reze Arc & Blood Fiends",
            hindiTitle = "चेनसॉ मैन",
            description = "Denji encounters the enigmatic bomb devil hybrid Reze under the rainy night skies of Tokyo, sparking explosive action, betrayal, and dark love.",
            category = MediaCategory.ANIME,
            genres = listOf("Action", "Gore", "Supernatural"),
            releaseYear = 2025,
            rating = 9.2,
            durationOrSeasons = "1h 58m Movie",
            isTrending = false,
            isFeatured = false,
            cast = listOf("Kikunosuke Toya", "Reina Ueda", "Tomori Kusunoki"),
            primaryColorHex = 0xFFFF5722,
            secondaryColorHex = 0xFF212121
        ),
        MediaItem(
            id = "ani_05",
            title = "Attack on Titan: Chronicles of Paradis",
            hindiTitle = "अटैक ऑन टाइटन",
            description = "Relive the legendary saga of freedom, titans, and the battle across the sea in breathtaking remastered 4K Dolby Atmos audio.",
            category = MediaCategory.ANIME,
            genres = listOf("Action", "Drama", "Mystery"),
            releaseYear = 2024,
            rating = 9.8,
            durationOrSeasons = "4 Seasons • 89 Episodes",
            isTrending = false,
            isFeatured = false,
            cast = listOf("Yuki Kaji", "Yui Ishikawa", "Hiroshi Kamiya"),
            primaryColorHex = 0xFF4A148C,
            secondaryColorHex = 0xFFB71C1C
        ),

        // ==================== MIDNIGHT SHOWS (LATE NIGHT SPECIALS) ====================
        MediaItem(
            id = "mid_01",
            title = "Midnight Caller: 3:00 AM Radio",
            hindiTitle = "मिडनाइट कॉलर (१८+ थ्रिलर)",
            description = "An eccentric late-night radio DJ receives anonymous phone calls from a serial caller confessing to crimes occurring in real-time right as listeners tune in past midnight.",
            category = MediaCategory.MIDNIGHT,
            genres = listOf("Late Night Horror", "Psychological Thriller", "Mystery 18+"),
            releaseYear = 2026,
            rating = 8.8,
            durationOrSeasons = "Season 1 • 6 Midnight Episodes",
            isMidnightExclusive = true,
            isTrending = true,
            isFeatured = true,
            cast = listOf("Arjun Rampal", "Radhika Apte", "Jim Sarbh"),
            episodes = (1..6).map { ep ->
                Episode(
                    id = "mid_01_ep$ep",
                    mediaId = "mid_01",
                    seasonNumber = 1,
                    episodeNumber = ep,
                    title = when (ep) {
                        1 -> "Call 01: The Whisper in the Static (3:05 AM)"
                        2 -> "Call 02: Blood on the Studio Glass"
                        3 -> "Call 03: The Confession of Room 13"
                        4 -> "Call 04: The Red Door at Highway 66"
                        5 -> "Call 05: Don't Look in the Rearview Mirror"
                        else -> "Call 06: The Final Broadcast at 4:00 AM"
                    },
                    durationMinutes = 48,
                    synopsis = "Dark confessions delivered over live frequency while the city sleeps."
                )
            },
            primaryColorHex = 0xFF9D00FF,
            secondaryColorHex = 0xFFFF0055
        ),
        MediaItem(
            id = "mid_02",
            title = "Sin City After Dark: Red Velvet Club",
            hindiTitle = "रेड वेलवेट क्लब",
            description = "In the forbidden underground cabaret of a neon metropolis, dangerous secrets, glamorous heists, and lethal rivalries unravel behind closed velvet curtains.",
            category = MediaCategory.MIDNIGHT,
            genres = listOf("Neon Noir", "Suspense", "Mature Crime 18+"),
            releaseYear = 2025,
            rating = 9.0,
            durationOrSeasons = "2h 18m Special",
            isMidnightExclusive = true,
            isTrending = true,
            isFeatured = false,
            cast = listOf("Kay Kay Menon", "Nora Fatehi", "Jaideep Ahlawat"),
            primaryColorHex = 0xFFFF0055,
            secondaryColorHex = 0xFF4A0033
        ),
        MediaItem(
            id = "mid_03",
            title = "The Haunting of Manor 13",
            hindiTitle = "हॉरर मैनर १३",
            description = "A team of paranormal investigators livestreams inside an abandoned Gothic sanatorium where the former inmates are rumored to hold dark rituals on full moon midnights.",
            category = MediaCategory.MIDNIGHT,
            genres = listOf("Supernatural Horror", "Found Footage", "18+ Jump Scares"),
            releaseYear = 2026,
            rating = 8.5,
            durationOrSeasons = "1h 52m",
            isMidnightExclusive = true,
            isTrending = false,
            isFeatured = false,
            cast = listOf("Evan Peters", "Sarah Paulson", "Finn Wittrock"),
            primaryColorHex = 0xFF0D47A1,
            secondaryColorHex = 0xFFB71C1C
        ),
        MediaItem(
            id = "mid_04",
            title = "Dark Web Diaries: The Red Room Mystery",
            hindiTitle = "डार्क वेब डायरीज",
            description = "An undercover cybersecurity analyst infiltrates encrypted darknet forums to expose a syndicate of masked illusionists orchestrating mind-bending games.",
            category = MediaCategory.MIDNIGHT,
            genres = listOf("Cyber-Horror", "Docu-Thriller", "Mind-Game"),
            releaseYear = 2025,
            rating = 8.9,
            durationOrSeasons = "Season 1 • 8 Episodes",
            isMidnightExclusive = true,
            isTrending = true,
            isFeatured = false,
            cast = listOf("Rami Malek", "Christian Slater", "Carly Chaikin"),
            episodes = (1..8).map { ep ->
                Episode(
                    id = "mid_04_ep$ep",
                    mediaId = "mid_04",
                    seasonNumber = 1,
                    episodeNumber = ep,
                    title = "File #0$ep: The Encrypted Cipher",
                    durationMinutes = 42,
                    synopsis = "Uncovering digital footprints of the underground darknet syndicate."
                )
            },
            primaryColorHex = 0xFF00E676,
            secondaryColorHex = 0xFF12005E
        ),
        MediaItem(
            id = "mid_05",
            title = "Night Shift: Room 404",
            hindiTitle = "नाईट शिफ्ट: रूम ४०४",
            description = "A solo night security guard at a luxury hotel is strictly ordered never to unlock Room 404 between midnight and 5:00 AM. Tonight, someone knocks from inside.",
            category = MediaCategory.MIDNIGHT,
            genres = listOf("Psychological Horror", "Suspense Thriller"),
            releaseYear = 2026,
            rating = 8.7,
            durationOrSeasons = "1h 45m",
            isMidnightExclusive = true,
            isTrending = false,
            isFeatured = false,
            cast = listOf("Gulshan Devaiah", "Tillotama Shome"),
            primaryColorHex = 0xFF6200EA,
            secondaryColorHex = 0xFFD50000
        ),

        // ==================== WEB SERIES ====================
        MediaItem(
            id = "ser_01",
            title = "Mirzapur: Throne of Blood Season 3",
            hindiTitle = "मिर्जापुर सीजन ३",
            description = "With the throne of Purvanchal up for grabs, Guddu Pandit and Golu Gupta unleash ruthless revenge across Uttar Pradesh to claim absolute dominance over the underworld.",
            category = MediaCategory.SERIES,
            genres = listOf("Crime", "Drama", "Action", "Underworld"),
            releaseYear = 2025,
            rating = 9.4,
            durationOrSeasons = "Season 3 • 10 Episodes",
            isTrending = true,
            isFeatured = true,
            cast = listOf("Pankaj Tripathi (Kaleen Bhaiya)", "Ali Fazal (Guddu)", "Shweta Tripathi", "Vijay Varma"),
            episodes = (1..10).map { ep ->
                Episode(
                    id = "ser_01_ep$ep",
                    mediaId = "ser_01",
                    seasonNumber = 3,
                    episodeNumber = ep,
                    title = when (ep) {
                        1 -> "Episode 1: Gaddi Ka Khel"
                        2 -> "Episode 2: Badla Aur Barood"
                        3 -> "Episode 3: Rakt Charitra"
                        4 -> "Episode 4: Purvanchal Under Siege"
                        5 -> "Episode 5: Satta Ka Nasha"
                        6 -> "Episode 6: The Bahubali Treaty"
                        7 -> "Episode 7: Blood Oath"
                        8 -> "Episode 8: The Betrayal at Sunset"
                        9 -> "Episode 9: The Siege of Jaunpur"
                        else -> "Episode 10: King of Mirzapur Forever"
                    },
                    durationMinutes = 55,
                    synopsis = "Power shifts as guns echo across the alleys of Mirzapur in the pursuit of vengeance."
                )
            },
            primaryColorHex = 0xFFFFB800,
            secondaryColorHex = 0xFFE50914
        ),
        MediaItem(
            id = "ser_02",
            title = "Stranger Realities: Season 5",
            hindiTitle = "स्ट्रेंजर रियलिटीज",
            description = "The gates to the dark Upside Down tear open into the real world. Eleven and the gang assemble for the ultimate inter-dimensional battle to save Hawkins and humanity.",
            category = MediaCategory.SERIES,
            genres = listOf("Sci-Fi", "Mystery", "Supernatural", "80s Nostalgia"),
            releaseYear = 2026,
            rating = 9.5,
            durationOrSeasons = "Season 5 • 8 Episodes",
            isTrending = true,
            isFeatured = true,
            cast = listOf("Millie Bobby Brown", "Finn Wolfhard", "David Harbour", "Winona Ryder"),
            episodes = (1..8).map { ep ->
                Episode(
                    id = "ser_02_ep$ep",
                    mediaId = "ser_02",
                    seasonNumber = 5,
                    episodeNumber = ep,
                    title = "Chapter $ep: The Final Gate of Vecna",
                    durationMinutes = 68,
                    synopsis = "Dark lightning rips across Hawkins as the heroes prepare for the war of worlds."
                )
            },
            primaryColorHex = 0xFFE50914,
            secondaryColorHex = 0xFF311B92
        ),
        MediaItem(
            id = "ser_03",
            title = "The Boys: Vought Fallout Season 5",
            hindiTitle = "द बॉयज",
            description = "Homelander asserts absolute supreme rule as Billy Butcher unleashes a lethal super-virus. The chaotic, violent war for civilization reaches its ultimate climax.",
            category = MediaCategory.SERIES,
            genres = listOf("Dark Superhero", "Action", "Satire 18+"),
            releaseYear = 2026,
            rating = 9.3,
            durationOrSeasons = "Season 5 • 8 Episodes",
            isTrending = true,
            isFeatured = false,
            cast = listOf("Antony Starr (Homelander)", "Karl Urban (Butcher)", "Jack Quaid", "Erin Moriarty"),
            episodes = (1..8).map { ep ->
                Episode(
                    id = "ser_03_ep$ep",
                    mediaId = "ser_03",
                    seasonNumber = 5,
                    episodeNumber = ep,
                    title = "Episode $ep: God Complex",
                    durationMinutes = 58,
                    synopsis = "Vought Corporation faces total collapse as supes run wild."
                )
            },
            primaryColorHex = 0xFFD50000,
            secondaryColorHex = 0xFF212121
        ),
        MediaItem(
            id = "ser_04",
            title = "Sacred Games: Zero Hour",
            hindiTitle = "सेक्रेड गेम्स",
            description = "Sartaj Singh uncovers a hidden continuation of Ganesh Gaitonde's cryptic nuclear conspiracy buried beneath the archives of Mumbai.",
            category = MediaCategory.SERIES,
            genres = listOf("Crime Thriller", "Mystery", "Drama"),
            releaseYear = 2025,
            rating = 9.1,
            durationOrSeasons = "Season 3 • 8 Episodes",
            isTrending = false,
            isFeatured = false,
            cast = listOf("Saif Ali Khan", "Nawazuddin Siddiqui", "Radhika Apte"),
            episodes = (1..8).map { ep ->
                Episode(
                    id = "ser_04_ep$ep",
                    mediaId = "ser_04",
                    seasonNumber = 3,
                    episodeNumber = ep,
                    title = "Episode $ep: Aham Brahmasmi Part $ep",
                    durationMinutes = 50,
                    synopsis = "A ticking clock over Mumbai threatens to end the city in nuclear fire."
                )
            },
            primaryColorHex = 0xFFFF6D00,
            secondaryColorHex = 0xFF3E2723
        ),
        MediaItem(
            id = "ser_05",
            title = "Money Heist: Tokyo's Ghost",
            hindiTitle = "मनी हाइस्ट",
            description = "The Professor orchestrates a final unprecedented heist targeting the World Gold Reserve in Zurich, executing plans conceived with Tokyo before her legendary sacrifice.",
            category = MediaCategory.SERIES,
            genres = listOf("Heist", "Action", "Suspense Drama"),
            releaseYear = 2025,
            rating = 9.0,
            durationOrSeasons = "Part 6 • 8 Episodes",
            isTrending = true,
            isFeatured = false,
            cast = listOf("Álvaro Morte (The Professor)", "Pedro Alonso (Berlin)", "Úrsula Corberó"),
            episodes = (1..8).map { ep ->
                Episode(
                    id = "ser_05_ep$ep",
                    mediaId = "ser_05",
                    seasonNumber = 6,
                    episodeNumber = ep,
                    title = "Episode $ep: Bella Ciao Zurich",
                    durationMinutes = 52,
                    synopsis = "The Professor plays 4D chess with European intelligence agencies."
                )
            },
            primaryColorHex = 0xFFB71C1C,
            secondaryColorHex = 0xFF263238
        )
    )
}
