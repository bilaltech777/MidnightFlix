package com.example.data.download

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.DatabaseProvider
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.Cache
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.offline.DownloadManager
import java.io.File
import java.util.concurrent.Executor
import java.util.concurrent.Executors

@OptIn(UnstableApi::class)
object DownloadManagerHelper {

    private const val DOWNLOAD_CONTENT_DIRECTORY = "downloads"
    private const val MAX_CACHE_SIZE_BYTES = 1000L * 1024L * 1024L // 1 GB cache size

    @Volatile
    private var downloadManager: DownloadManager? = null

    @Volatile
    private var databaseProvider: DatabaseProvider? = null

    @Volatile
    private var downloadCache: Cache? = null

    @Volatile
    private var downloadExecutor: Executor? = null

    fun getDatabaseProvider(context: Context): DatabaseProvider {
        return databaseProvider ?: synchronized(this) {
            databaseProvider ?: StandaloneDatabaseProvider(context.applicationContext).also {
                databaseProvider = it
            }
        }
    }

    fun getDownloadCache(context: Context): Cache {
        return downloadCache ?: synchronized(this) {
            downloadCache ?: run {
                val downloadDirectory = File(context.applicationContext.filesDir, DOWNLOAD_CONTENT_DIRECTORY)
                val evictor = LeastRecentlyUsedCacheEvictor(MAX_CACHE_SIZE_BYTES)
                SimpleCache(downloadDirectory, evictor, getDatabaseProvider(context)).also {
                    downloadCache = it
                }
            }
        }
    }

    fun getDownloadExecutor(): Executor {
        return downloadExecutor ?: synchronized(this) {
            downloadExecutor ?: Executors.newFixedThreadPool(6).also {
                downloadExecutor = it
            }
        }
    }

    fun getHttpDataSourceFactory(): DataSource.Factory {
        return DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000)
    }

    fun getDownloadManager(context: Context): DownloadManager {
        return downloadManager ?: synchronized(this) {
            downloadManager ?: run {
                val appContext = context.applicationContext
                val dbProvider = getDatabaseProvider(appContext)
                val cache = getDownloadCache(appContext)
                val dataSourceFactory = getHttpDataSourceFactory()
                val executor = getDownloadExecutor()

                val manager = DownloadManager(
                    appContext,
                    dbProvider,
                    cache,
                    dataSourceFactory,
                    executor
                )
                manager.maxParallelDownloads = 3
                downloadManager = manager
                manager
            }
        }
    }

    fun startDownload(context: Context, mediaId: String, videoUrl: String) {
        val request = androidx.media3.exoplayer.offline.DownloadRequest.Builder(
            mediaId,
            android.net.Uri.parse(videoUrl)
        ).build()

        getDownloadManager(context).addDownload(request)
    }
}
