package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class DownloadState {
    PENDING,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED
}

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: String, // mediaId or mediaId_season_ep
    val mediaId: String,
    val episodeId: String? = null,
    val title: String,
    val subtitle: String, // e.g. "Season 1 • Ep 3" or "2h 15m • Action"
    val categoryName: String,
    val quality: String, // "480p", "720p", "1080p"
    val totalSizeMb: Int,
    val downloadedMb: Float,
    val progressPercent: Int,
    val downloadSpeedText: String = "12.4 MB/s",
    val status: DownloadState,
    val timestamp: Long = System.currentTimeMillis(),
    val primaryColorHex: Long = 0xFFE50914,
    val secondaryColorHex: Long = 0xFF7928CA
)

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey val id: String, // mediaId
    val mediaId: String,
    val episodeId: String? = null,
    val title: String,
    val subtitle: String,
    val categoryName: String,
    val watchedSeconds: Long,
    val totalDurationSeconds: Long,
    val lastQualityUsed: String,
    val timestamp: Long = System.currentTimeMillis(),
    val primaryColorHex: Long = 0xFFE50914
)

@Entity(tableName = "watchlist")
data class WatchlistEntity(
    @PrimaryKey val mediaId: String,
    val title: String,
    val categoryName: String,
    val rating: Double,
    val timestamp: Long = System.currentTimeMillis()
)
