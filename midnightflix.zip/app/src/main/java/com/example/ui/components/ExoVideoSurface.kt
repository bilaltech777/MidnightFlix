package com.example.ui.components

import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.util.Util
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.ui.viewmodel.PlayerState
import kotlinx.coroutines.delay

@OptIn(UnstableApi::class)
@Composable
fun ExoVideoSurface(
    playerState: PlayerState,
    onPositionUpdate: (Long) -> Unit,
    onDurationUpdate: (Long) -> Unit,
    onBufferingChange: (Boolean) -> Unit,
    onPlayerError: (String?) -> Unit,
    onPlaybackEnded: () -> Unit = {},
    onToggleControls: () -> Unit,
    onDoubleTapSeek: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val currentOnPositionUpdate by rememberUpdatedState(onPositionUpdate)
    val currentOnDurationUpdate by rememberUpdatedState(onDurationUpdate)
    val currentOnBufferingChange by rememberUpdatedState(onBufferingChange)
    val currentOnPlayerError by rememberUpdatedState(onPlayerError)
    val currentOnPlaybackEnded by rememberUpdatedState(onPlaybackEnded)

    // Visual Double-Tap Ripple State
    var doubleTapFeedback by remember { mutableStateOf<Pair<Boolean, String>?>(null) }

    LaunchedEffect(doubleTapFeedback) {
        if (doubleTapFeedback != null) {
            delay(650)
            doubleTapFeedback = null
        }
    }

    // Build ExoPlayer instance with custom resilient MediaSourceFactory
    val exoPlayer = remember {
        val userAgent = Util.getUserAgent(context, "MidnightFlix")
        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(userAgent)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000)

        val dataSourceFactory = DefaultDataSource.Factory(context, httpDataSourceFactory)
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)

        ExoPlayer.Builder(context)
            .setMediaSourceFactory(mediaSourceFactory)
            .build()
            .apply {
                playWhenReady = true
                repeatMode = Player.REPEAT_MODE_OFF
            }
    }

    // Attach Player Listener
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        currentOnBufferingChange(true)
                    }
                    Player.STATE_READY -> {
                        currentOnBufferingChange(false)
                        currentOnPlayerError(null)
                        val durationMs = exoPlayer.duration
                        if (durationMs > 0) {
                            currentOnDurationUpdate(durationMs / 1000L)
                        }
                    }
                    Player.STATE_ENDED -> {
                        currentOnBufferingChange(false)
                        currentOnPlaybackEnded()
                    }
                    Player.STATE_IDLE -> {
                        currentOnBufferingChange(false)
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                currentOnBufferingChange(false)
                val msg = error.message ?: "Unable to stream media. Network or codec error."
                currentOnPlayerError(msg)
            }

            override fun onEvents(
                player: Player,
                events: Player.Events
            ) {
                currentOnPositionUpdate(
                    player.currentPosition / 1000
                )
            }
        }

        exoPlayer.addListener(listener)

        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    // Lifecycle Observer to Pause/Resume playback when app enters background
    DisposableEffect(lifecycleOwner, exoPlayer) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    exoPlayer.pause()
                }
                Lifecycle.Event.ON_RESUME -> {
                    if (playerState.isPlaying && exoPlayer.playbackState == Player.STATE_READY) {
                        exoPlayer.play()
                    }
                }
                else -> {}
            }
        }
        val lifecycle = lifecycleOwner.lifecycle
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
        }
    }

    // Load Stream URL when it changes or reload is requested
    LaunchedEffect(
        playerState.streamUrl,
        playerState.reloadToken
    ) {
        val hlsUrl = playerState.streamUrl
        if (hlsUrl.isNotBlank()) {
            currentOnBufferingChange(true)
            val mediaItem =
                MediaItem.fromUri(hlsUrl)

            exoPlayer.setMediaItem(mediaItem)
            exoPlayer.prepare()
            val savedPosition = playerState.currentPositionSeconds
            exoPlayer.seekTo(
                savedPosition * 1000
            )
            exoPlayer.play()
        }
    }

    // Sync Play/Pause
    LaunchedEffect(playerState.isPlaying) {
        if (playerState.isPlaying) {
            exoPlayer.play()
        } else {
            exoPlayer.pause()
        }
    }

    // Sync Playback Speed
    LaunchedEffect(playerState.playbackSpeed) {
        exoPlayer.setPlaybackSpeed(playerState.playbackSpeed)
    }

    // Sync Volume / Mute
    LaunchedEffect(playerState.isMuted) {
        exoPlayer.volume = if (playerState.isMuted) 0f else 1f
    }

    // Sync Playback Position polling
    LaunchedEffect(playerState.isPlaying) {
        while (playerState.isPlaying) {
            val dur = exoPlayer.duration / 1000L
            if (dur > 0) {
                currentOnDurationUpdate(dur)
            }
            if (exoPlayer.currentPosition >= 0) {
                currentOnPositionUpdate(
                    exoPlayer.currentPosition / 1000
                )
            }
            delay(1000)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = {
                        onToggleControls()
                    },
                    onDoubleTap = { offset ->
                        val isRightSide = offset.x > (size.width / 2)
                        if (isRightSide) {
                            val newPos = (exoPlayer.currentPosition + 10_000).coerceAtMost(exoPlayer.duration)
                            exoPlayer.seekTo(newPos)
                            onDoubleTapSeek(10)
                            doubleTapFeedback = Pair(true, "+10s")
                        } else {
                            val newPos = (exoPlayer.currentPosition - 10_000).coerceAtLeast(0)
                            exoPlayer.seekTo(newPos)
                            onDoubleTapSeek(-10)
                            doubleTapFeedback = Pair(false, "-10s")
                        }
                    }
                )
            }
    ) {
        // Player View Component
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    useArtwork = false
                    keepScreenOn = true
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    resizeMode = when (playerState.resizeMode) {
                        1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        2 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                        else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                    setBackgroundColor(android.graphics.Color.BLACK)
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                }
            },
            update = { playerView ->
                playerView.player = exoPlayer
                playerView.resizeMode = when (playerState.resizeMode) {
                    1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    2 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            },
            onRelease = { playerView ->
                playerView.player = null
            },
            modifier = Modifier.fillMaxSize()
        )

        // Buffering Indicator
        AnimatedVisibility(
            visible = playerState.isBuffering,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .background(Color.Black.copy(alpha = 0.6f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color = Color(0xFFD0BCFF),
                    strokeWidth = 3.5.dp,
                    modifier = Modifier.size(42.dp)
                )
            }
        }

        // Animated Double-Tap Rewind / Forward Feedback
        AnimatedVisibility(
            visible = doubleTapFeedback != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(
                if (doubleTapFeedback?.first == true) Alignment.CenterEnd else Alignment.CenterStart
            )
        ) {
            doubleTapFeedback?.let { feedback ->
                val isForward = feedback.first
                Box(
                    modifier = Modifier
                        .padding(horizontal = 36.dp)
                        .background(Color.Black.copy(alpha = 0.75f), CircleShape)
                        .padding(18.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isForward) Icons.Default.FastForward else Icons.Default.FastRewind,
                        contentDescription = null,
                        tint = Color(0xFFD0BCFF),
                        modifier = Modifier.size(32.dp)
                    )
                    Text(
                        text = feedback.second,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 34.dp)
                    )
                }
            }
        }
    }
}
