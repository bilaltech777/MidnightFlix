package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Immersive UI Theme Palette
val MidnightBlack = Color(0xFF0F0F0F)
val MidnightDarkSurface = Color(0xFF1C1B1F)
val MidnightCardBg = Color(0xFF25232A)
val MidnightCardElevated = Color(0xFF2B2930)
val MidnightCardStroke = Color(0xFF49454F)

val ImmersivePrimary = Color(0xFFD0BCFF)
val ImmersiveOnPrimary = Color(0xFF381E72)
val ImmersiveSurfaceVariant = Color(0xFF49454F)
val ImmersivePrimaryContainer = Color(0xFF381E72)
val ImmersiveOnPrimaryContainer = Color(0xFFEADDFF)

val CinemaRed = Color(0xFFD0BCFF) // Main brand accent mapped to Immersive Primary
val CinemaRedBright = Color(0xFFEADDFF)
val NeonViolet = Color(0xFFD0BCFF)
val ElectricCyan = Color(0xFF80D8FF)
val VipGold = Color(0xFFFFD700)
val VipGoldDark = Color(0xFFC79E00)
val FreeGreen = Color(0xFF49454F)
val FreeGreenText = Color(0xFFE6E1E9)
val QualityBlue = Color(0xFFD0BCFF)

val TextPrimary = Color(0xFFE2E2E6)
val TextSecondary = Color(0xFFCAC4D0)
val TextMuted = Color(0xFF938F99)

val SurfaceOverlay = Color(0xCC0F0F0F)
val RedGlow = Color(0x33D0BCFF)
val PurpleGlow = Color(0x33381E72)
