package com.example.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaItem
import com.example.data.model.VideoQuality
import com.example.ui.theme.CinemaRed
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.MidnightBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VipGold
import kotlinx.coroutines.delay

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HeroBannerCarousel(
    featuredItems: List<MediaItem>,
    onItemClick: (MediaItem) -> Unit,
    onPlayClick: (MediaItem) -> Unit,
    onDownloadClick: (MediaItem) -> Unit,
    modifier: Modifier = Modifier
) {
    if (featuredItems.isEmpty()) return

    val pagerState = rememberPagerState(pageCount = { featuredItems.size })

    // Auto-advance
    LaunchedEffect(pagerState) {
        while (true) {
            delay(5000)
            if (featuredItems.isNotEmpty()) {
                val nextPage = (pagerState.currentPage + 1) % featuredItems.size
                pagerState.animateScrollToPage(nextPage)
            }
        }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier
                .fillMaxWidth()
                .height(340.dp)
        ) { page ->
            val item = featuredItems[page]
            val primaryColor = Color(item.primaryColorHex)
            val secondaryColor = Color(item.secondaryColorHex)

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                primaryColor.copy(alpha = 0.8f),
                                secondaryColor.copy(alpha = 0.95f),
                                MidnightBlack
                            )
                        )
                    )
            ) {
                // Background subtle mesh overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(Color.Transparent, MidnightBlack.copy(alpha = 0.8f)),
                                radius = 700f
                            )
                        )
                )

                // Foreground Content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 20.dp),
                    verticalArrangement = Arrangement.Bottom
                ) {
                    // Top badges
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CategoryBadge(category = item.category)

                        if (item.isMidnightExclusive) {
                            MidnightExclusiveBadge()
                        }

                        QualityBadge(quality = VideoQuality.P480)

                        // Rating
                        Row(
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = VipGold,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "${item.rating} • ${item.releaseYear}",
                                color = TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Title
                    Text(
                        text = item.title,
                        color = TextPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (item.hindiTitle.isNotEmpty()) {
                        Text(
                            text = item.hindiTitle,
                            color = ElectricCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Synopsis
                    Text(
                        text = item.description,
                        color = TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onPlayClick(item) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFD0BCFF),
                                contentColor = Color(0xFF381E72)
                            ),
                            shape = CircleShape,
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .testTag("hero_play_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF381E72), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("WATCH NOW", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF381E72))
                        }

                        OutlinedButton(
                            onClick = { onDownloadClick(item) },
                            shape = CircleShape,
                            modifier = Modifier
                                .weight(0.9f)
                                .height(42.dp)
                                .border(1.dp, Color(0xFFD0BCFF).copy(alpha = 0.5f), CircleShape)
                                .testTag("hero_download_button"),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = Color(0xFFD0BCFF).copy(alpha = 0.1f),
                                contentColor = Color(0xFFD0BCFF)
                            )
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFFD0BCFF), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Download", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Color(0xFFD0BCFF))
                        }

                        OutlinedButton(
                            onClick = { onItemClick(item) },
                            shape = CircleShape,
                            modifier = Modifier
                                .height(42.dp)
                                .border(1.dp, Color(0xFF49454F), CircleShape),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = Color(0xFF1C1B1F),
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Default.Info, contentDescription = "Details", tint = Color(0xFFCAC4D0), modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // Pager Indicators
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(featuredItems.size) { index ->
                val isSelected = pagerState.currentPage == index
                Box(
                    modifier = Modifier
                        .padding(horizontal = 3.dp)
                        .height(4.dp)
                        .width(if (isSelected) 22.dp else 6.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) Color(0xFFD0BCFF) else Color(0xFF49454F))
                )
            }
        }
    }
}
