package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ImmersiveColorScheme = darkColorScheme(
    primary = ImmersivePrimary,
    onPrimary = ImmersiveOnPrimary,
    primaryContainer = ImmersivePrimaryContainer,
    onPrimaryContainer = ImmersiveOnPrimaryContainer,
    secondary = ImmersivePrimary,
    onSecondary = ImmersiveOnPrimary,
    secondaryContainer = ImmersiveSurfaceVariant,
    onSecondaryContainer = Color(0xFFE6E1E9),
    tertiary = VipGold,
    onTertiary = Color.Black,
    background = MidnightBlack,
    onBackground = TextPrimary,
    surface = MidnightDarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = MidnightCardElevated,
    onSurfaceVariant = TextSecondary,
    outline = MidnightCardStroke,
    error = Color(0xFFFF5252)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    // Enforce Immersive UI design theme
    MaterialTheme(
        colorScheme = ImmersiveColorScheme,
        typography = Typography,
        content = content
    )
}
