package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaCategory
import com.example.data.model.VideoQuality

@Composable
fun QualityBadge(
    quality: VideoQuality,
    modifier: Modifier = Modifier
) {
    val (bgColor, strokeColor, textColor, labelText) = when (quality) {
        VideoQuality.P480 -> Quad(
            Color(0xFF2B2930),
            Color(0xFF49454F),
            Color(0xFFCAC4D0),
            "480p FREE"
        )
        VideoQuality.P720 -> Quad(
            Color(0xFF1C1B1F),
            Color(0xFFD0BCFF).copy(alpha = 0.5f),
            Color(0xFFD0BCFF),
            "720p PRO"
        )
        VideoQuality.P1080 -> Quad(
            Color(0xFF381E72).copy(alpha = 0.6f),
            Color(0xFFD0BCFF),
            Color(0xFFD0BCFF),
            "1080p VIP"
        )
        VideoQuality.P4K -> Quad(
            Color(0xFF4F378B).copy(alpha = 0.7f),
            Color(0xFFD0BCFF),
            Color(0xFFFFFFFF),
            "4K ULTRA"
        )
    }

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(6.dp))
            .border(1.dp, strokeColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = labelText,
            color = textColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Composable
fun CategoryBadge(
    category: MediaCategory,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(Color(0xFF1C1B1F), RoundedCornerShape(6.dp))
            .border(1.dp, Color(0xFF49454F), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = category.displayName.uppercase(),
            color = Color(0xFFCAC4D0),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun MidnightExclusiveBadge(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(
                Brush.horizontalGradient(listOf(Color(0xFF6750A4), Color(0xFF381E72))),
                RoundedCornerShape(6.dp)
            )
            .border(1.dp, Color(0xFFD0BCFF).copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = "MIDNIGHT 18+",
            color = Color(0xFFD0BCFF),
            fontSize = 9.sp,
            fontWeight = FontWeight.Black
        )
    }
}
