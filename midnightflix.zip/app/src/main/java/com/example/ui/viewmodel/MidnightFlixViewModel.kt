package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.DownloadEntity
import com.example.data.local.WatchHistoryEntity
import com.example.data.local.WatchlistEntity
import com.example.data.model.Episode
import com.example.data.model.MediaCategory
import com.example.data.model.MediaItem
import com.example.data.model.SubscriptionPlan
import com.example.data.model.UserProfile
import com.example.data.model.VideoQuality
import com.example.data.repository.MediaRepository
import com.example.data.repository.UserRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppNavScreen {
    HOME,
    EXPLORE,
    MIDNIGHT_HUB,
    AI_STUDIO,
    DOWNLOADS,
    PROFILE,
    MEDIA_DETAILS,
    VIDEO_PLAYER
}

data class PlayerState(
    val mediaItem: MediaItem? = null,
    val selectedEpisode: Episode? = null,
    val currentQuality: VideoQuality = VideoQuality.P480,
    val isPlaying: Boolean = true,
    val currentPositionSeconds: Long = 0L,
    val totalDurationSeconds: Long = 7200L,
    val audioLanguage: String = "Hindi",
    val subtitleLanguage: String = "English",
    val isBuffering: Boolean = false,
    val isFullscreen: Boolean = false,
    val isControlsVisible: Boolean = true,
    val isOfflineMode: Boolean = false,
    val playbackSpeed: Float = 1.0f,
    val isMuted: Boolean = false,
    val resizeMode: Int = 0, // 0: Fit, 1: Zoom / Fill, 2: Stretch
    val streamUrl: String = "",
    val errorMessage: String? = null,
    val reloadToken: Long = 0L
)

class MidnightFlixViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val mediaRepository = MediaRepository(db)
    val userRepository = UserRepository()

    // Navigation
    private val _currentScreen = MutableStateFlow(AppNavScreen.HOME)
    val currentScreen: StateFlow<AppNavScreen> = _currentScreen.asStateFlow()

    // Selected Media & Details
    private val _selectedMediaItem = MutableStateFlow<MediaItem?>(null)
    val selectedMediaItem: StateFlow<MediaItem?> = _selectedMediaItem.asStateFlow()

    // Video Player State
    private val _playerState = MutableStateFlow(PlayerState())
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()

    // Search & Filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow(MediaCategory.ALL)
    val selectedCategory: StateFlow<MediaCategory> = _selectedCategory.asStateFlow()

    // Dialogs & Sheets
    private val _showVipUpgradeDialog = MutableStateFlow(false)
    val showVipUpgradeDialog: StateFlow<Boolean> = _showVipUpgradeDialog.asStateFlow()

    private val _downloadTargetMedia = MutableStateFlow<Pair<MediaItem, Episode?>?>(null)
    val downloadTargetMedia: StateFlow<Pair<MediaItem, Episode?>?> = _downloadTargetMedia.asStateFlow()

    private val _vipDialogReason = MutableStateFlow("Unlock 1080p Full HD & High-Speed Downloads")
    val vipDialogReason: StateFlow<String> = _vipDialogReason.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // User Profile
    val userProfile: StateFlow<UserProfile> = userRepository.userProfile

    // Downloads
    val downloads: StateFlow<List<DownloadEntity>> = mediaRepository.downloadsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Watch History
    val watchHistory: StateFlow<List<WatchHistoryEntity>> = mediaRepository.watchHistoryFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // My List / Watchlist
    val watchlist: StateFlow<List<WatchlistEntity>> = mediaRepository.watchlistFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun isItemInWatchlist(mediaId: String): Flow<Boolean> = mediaRepository.isInWatchlist(mediaId)

    fun toggleWatchlist(mediaItem: MediaItem, isCurrentlyInList: Boolean) {
        mediaRepository.toggleWatchlist(mediaItem, isCurrentlyInList)
        if (isCurrentlyInList) {
            showToast("Removed from My List")
        } else {
            showToast("Saved to My List")
        }
    }

    fun removeFromWatchlist(mediaId: String) {
        viewModelScope.launch {
            mediaRepository.toggleWatchlist(
                MediaItem(
                    id = mediaId,
                    title = "",
                    description = "",
                    category = MediaCategory.MOVIE,
                    rating = 0.0,
                    releaseYear = 2024,
                    durationOrSeasons = "",
                    genres = emptyList(),
                    cast = emptyList()
                ),
                isCurrentlyInList = true
            )
            showToast("Removed from My List")
        }
    }

    fun deleteWatchHistory(id: String) {
        viewModelScope.launch {
            mediaRepository.deleteWatchHistory(id)
            showToast("Removed from Viewing History")
        }
    }

    fun clearWatchHistory() {
        viewModelScope.launch {
            mediaRepository.clearWatchHistory()
            showToast("Viewing History Cleared")
        }
    }

    // Explore / Search results
    val searchResults: StateFlow<List<MediaItem>> = combine(_searchQuery, _selectedCategory) { query, category ->
        mediaRepository.searchMedia(query, category)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), mediaRepository.getAllMedia())

    fun navigateTo(screen: AppNavScreen) {
        _currentScreen.value = screen
    }

    fun openMediaDetails(mediaItem: MediaItem) {
        _selectedMediaItem.value = mediaItem
        _currentScreen.value = AppNavScreen.MEDIA_DETAILS
    }

    fun playMedia(
        mediaItem: MediaItem,
        episode: Episode? = null,
        preferredQuality: VideoQuality = VideoQuality.P480,
        isOffline: Boolean = false
    ) {
        val user = userProfile.value
        val qualityToUse = if (user.canAccessQuality(preferredQuality)) {
            preferredQuality
        } else {
            VideoQuality.P480 // fallback to free 480p
        }

        val streamUrl = mediaItem.getStreamUrl(episode, qualityToUse)
        val totalSec = if (episode != null) episode.durationMinutes * 60L else 7200L
        _playerState.value = PlayerState(
            mediaItem = mediaItem,
            selectedEpisode = episode,
            currentQuality = qualityToUse,
            isPlaying = true,
            currentPositionSeconds = 0L,
            totalDurationSeconds = totalSec,
            audioLanguage = mediaItem.audioLanguages.firstOrNull() ?: "Hindi",
            subtitleLanguage = "English",
            isControlsVisible = true,
            isOfflineMode = isOffline,
            streamUrl = streamUrl,
            playbackSpeed = 1.0f,
            isMuted = false,
            isBuffering = false,
            errorMessage = null
        )
        _currentScreen.value = AppNavScreen.VIDEO_PLAYER

        // Record watch history
        mediaRepository.saveWatchProgress(mediaItem, episode, 10L, totalSec, qualityToUse)
    }

    fun updatePlayerPosition(seconds: Long) {
        val cur = _playerState.value
        val validTotal = if (cur.totalDurationSeconds > 0) cur.totalDurationSeconds else 7200L
        _playerState.value = cur.copy(currentPositionSeconds = seconds.coerceIn(0, validTotal))
        cur.mediaItem?.let { item ->
            mediaRepository.saveWatchProgress(item, cur.selectedEpisode, seconds, validTotal, cur.currentQuality)
        }
    }

    fun setPlayerDuration(durationSeconds: Long) {
        if (durationSeconds > 0) {
            _playerState.value = _playerState.value.copy(totalDurationSeconds = durationSeconds)
        }
    }

    fun setPlaying(isPlaying: Boolean) {
        _playerState.value = _playerState.value.copy(isPlaying = isPlaying)
    }

    fun setBuffering(isBuffering: Boolean) {
        _playerState.value = _playerState.value.copy(isBuffering = isBuffering)
    }

    fun setPlayerError(error: String?) {
        _playerState.value = _playerState.value.copy(errorMessage = error, isBuffering = false)
    }

    fun retryPlayback() {
        val cur = _playerState.value
        _playerState.value = cur.copy(
            reloadToken = System.currentTimeMillis(),
            isBuffering = true,
            errorMessage = null
        )
    }

    fun setPlaybackSpeed(speed: Float) {
        _playerState.value = _playerState.value.copy(playbackSpeed = speed)
        showToast("Speed: ${speed}x")
    }

    fun toggleMute() {
        val newMute = !_playerState.value.isMuted
        _playerState.value = _playerState.value.copy(isMuted = newMute)
        showToast(if (newMute) "Muted" else "Unmuted")
    }

    fun setResizeMode(mode: Int) {
        _playerState.value = _playerState.value.copy(resizeMode = mode)
        val modeName = when (mode) {
            0 -> "Fit to Screen"
            1 -> "Zoom / Crop"
            else -> "Stretch / Fill"
        }
        showToast("Aspect: $modeName")
    }

    fun togglePlayPause() {
        val cur = _playerState.value
        _playerState.value = cur.copy(isPlaying = !cur.isPlaying)
    }

    fun skipTime(secondsOffset: Long) {
        val cur = _playerState.value
        val validTotal = if (cur.totalDurationSeconds > 0) cur.totalDurationSeconds else 7200L
        val newPos = (cur.currentPositionSeconds + secondsOffset).coerceIn(0, validTotal)
        _playerState.value = cur.copy(currentPositionSeconds = newPos)
    }

    fun switchQuality(quality: VideoQuality) {
        val user = userProfile.value
        if (user.canAccessQuality(quality)) {
            val cur = _playerState.value
            val currentPos = cur.currentPositionSeconds
            val newStreamUrl = cur.mediaItem?.getStreamUrl(
                cur.selectedEpisode,
                quality
            ) ?: ""

            _playerState.value = cur.copy(
                currentQuality = quality,
                streamUrl = newStreamUrl,
                currentPositionSeconds = currentPos,
                isBuffering = true,
                errorMessage = null
            )
            showToast("Switched stream to ${quality.label} (${quality.resolutionText})")
        } else {
            _vipDialogReason.value = "Switching to ${quality.label} requires ${quality.requiresVipTier}. 480p is Free for all users."
            _showVipUpgradeDialog.value = true
        }
    }

    fun setAudioLanguage(lang: String) {
        _playerState.value = _playerState.value.copy(audioLanguage = lang)
        showToast("Audio set to $lang")
    }

    fun setSubtitleLanguage(sub: String) {
        _playerState.value = _playerState.value.copy(subtitleLanguage = sub)
        showToast("Subtitles set to $sub")
    }

    fun toggleFullscreen() {
        _playerState.value = _playerState.value.copy(isFullscreen = !_playerState.value.isFullscreen)
    }

    fun toggleControlsVisibility() {
        _playerState.value = _playerState.value.copy(isControlsVisible = !_playerState.value.isControlsVisible)
    }

    fun playNextEpisode(): Boolean {
        val episodes = _playerState.value.mediaItem?.episodes ?: return false
        val current = _playerState.value.selectedEpisode ?: return false
        val index = episodes.indexOf(current)

        if (index < episodes.lastIndex) {
            val nextEpisode = episodes[index + 1]
            playMedia(
                _playerState.value.mediaItem ?: return false,
                nextEpisode
            )
            return true
        }
        return false
    }

    // ==================== DOWNLOAD ACTIONS ====================
    fun openDownloadDialog(mediaItem: MediaItem, episode: Episode? = null) {
        _downloadTargetMedia.value = Pair(mediaItem, episode)
    }

    fun closeDownloadDialog() {
        _downloadTargetMedia.value = null
    }

    fun requestDownloadWithQuality(quality: VideoQuality) {
        val target = _downloadTargetMedia.value ?: return
        val user = userProfile.value

        if (user.canAccessQuality(quality)) {
            mediaRepository.startDownload(target.first, target.second, quality)
            closeDownloadDialog()
            showToast("Downloading ${target.first.title} in ${quality.label}...")
        } else {
            closeDownloadDialog()
            _vipDialogReason.value = "Downloading in ${quality.label} is a Paid feature (${quality.requiresVipTier}). You can download 480p for Free!"
            _showVipUpgradeDialog.value = true
        }
    }

    fun pauseDownload(id: String) {
        mediaRepository.pauseDownload(id)
        showToast("Download paused")
    }

    fun resumeDownload(id: String) {
        mediaRepository.resumeDownload(id)
        showToast("Download resumed")
    }

    fun deleteDownload(id: String) {
        mediaRepository.deleteDownload(id)
        showToast("Download deleted")
    }

    fun clearAllDownloads() {
        mediaRepository.clearAllDownloads()
        showToast("All downloads cleared")
    }

    // ==================== USER / VIP ACTIONS ====================
    fun openVipDialog(reason: String = "Get Full VIP Access (720p HD, 1080p FHD, 4K & Unlimited Downloads)") {
        _vipDialogReason.value = reason
        _showVipUpgradeDialog.value = true
    }

    fun closeVipDialog() {
        _showVipUpgradeDialog.value = false
    }

    fun toggleOwnerMode(enabled: Boolean) {
        userRepository.toggleOwnerMode(enabled)
        if (enabled) {
            showToast("Owner Mode Activated: Lifetime 1080p/4K VIP Unlocked!")
        } else {
            showToast("Guest Mode Activated: 480p Free, 720p/1080p Paid")
        }
    }

    fun upgradePlan(plan: SubscriptionPlan) {
        userRepository.updatePlan(plan)
        closeVipDialog()
        showToast("Upgraded to ${plan.title} successfully!")
    }

    fun redeemPromoCode(code: String) {
        val success = userRepository.redeemVipCode(code)
        if (success) {
            closeVipDialog()
            showToast("VIP Code Applied! Premium Unlocked.")
        } else {
            showToast("Invalid code. Use 'VIP2026' or 'BILALVIP'")
        }
    }

    // ==================== SEARCH & FILTERS ====================
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: MediaCategory) {
        _selectedCategory.value = category
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    // ==================== GEMINI AI CINESTUDIO STATE ====================
    private val _aiChatMessages = MutableStateFlow<List<com.example.data.ai.ChatMessage>>(
        listOf(
            com.example.data.ai.ChatMessage(
                role = "model",
                text = "👋 Welcome to **CineAI Concierge**! I am your personal AI cinema expert. Ask me for recommendations, plot twists analysis, hidden Easter eggs, or let me generate custom film posters for you!"
            )
        )
    )
    val aiChatMessages: StateFlow<List<com.example.data.ai.ChatMessage>> = _aiChatMessages.asStateFlow()

    private val _isAiChatGenerating = MutableStateFlow(false)
    val isAiChatGenerating: StateFlow<Boolean> = _isAiChatGenerating.asStateFlow()

    // Deep Analysis State
    private val _deepAnalysisText = MutableStateFlow<String?>(null)
    val deepAnalysisText: StateFlow<String?> = _deepAnalysisText.asStateFlow()

    private val _isAnalyzingDeep = MutableStateFlow(false)
    val isAnalyzingDeep: StateFlow<Boolean> = _isAnalyzingDeep.asStateFlow()

    // Trivia State
    private val _triviaList = MutableStateFlow<List<com.example.data.ai.AiTriviaItem>>(emptyList())
    val triviaList: StateFlow<List<com.example.data.ai.AiTriviaItem>> = _triviaList.asStateFlow()

    private val _isLoadingTrivia = MutableStateFlow(false)
    val isLoadingTrivia: StateFlow<Boolean> = _isLoadingTrivia.asStateFlow()

    // Poster Generation State
    private val _generatedPoster = MutableStateFlow<com.example.data.ai.GeneratedPosterResult?>(null)
    val generatedPoster: StateFlow<com.example.data.ai.GeneratedPosterResult?> = _generatedPoster.asStateFlow()

    private val _isGeneratingPoster = MutableStateFlow(false)
    val isGeneratingPoster: StateFlow<Boolean> = _isGeneratingPoster.asStateFlow()

    fun sendAiChatMessage(userMessage: String, movieContext: String? = null) {
        if (userMessage.isBlank()) return
        val currentHistory = _aiChatMessages.value
        val userMsgObj = com.example.data.ai.ChatMessage(
            role = "user",
            text = userMessage,
            movieContextTitle = movieContext
        )
        _aiChatMessages.value = currentHistory + userMsgObj
        _isAiChatGenerating.value = true

        viewModelScope.launch {
            val result = com.example.data.ai.GeminiAiService.sendChatMessage(
                conversationHistory = currentHistory,
                userMessage = userMessage,
                movieContext = movieContext
            )

            _isAiChatGenerating.value = false
            result.onSuccess { reply ->
                _aiChatMessages.value = _aiChatMessages.value + com.example.data.ai.ChatMessage(
                    role = "model",
                    text = reply,
                    movieContextTitle = movieContext
                )
            }.onFailure { err ->
                _aiChatMessages.value = _aiChatMessages.value + com.example.data.ai.ChatMessage(
                    role = "model",
                    text = "⚠️ CineAI Notice: ${err.message ?: "Unable to fetch AI response at this moment."}"
                )
            }
        }
    }

    fun clearAiChat() {
        _aiChatMessages.value = listOf(
            com.example.data.ai.ChatMessage(
                role = "model",
                text = "✨ Conversation reset! Ask me anything about movies, characters, directors, or Hindi dubbed series."
            )
        )
    }

    fun requestDeepAnalysis(mediaItem: MediaItem, aspect: String = "Themes, Symbolism & Philosophy") {
        _isAnalyzingDeep.value = true
        _deepAnalysisText.value = null
        viewModelScope.launch {
            val result = com.example.data.ai.GeminiAiService.analyzeMovieDeep(
                movieTitle = mediaItem.title,
                genre = mediaItem.genres.joinToString(", "),
                description = mediaItem.description,
                aspectToAnalyze = aspect
            )
            _isAnalyzingDeep.value = false
            result.onSuccess { analysis ->
                _deepAnalysisText.value = analysis
            }.onFailure { err ->
                _deepAnalysisText.value = "⚠️ Analysis Note: ${err.message ?: "Unable to run deep breakdown."}"
            }
        }
    }

    fun fetchMediaTrivia(mediaItem: MediaItem) {
        _isLoadingTrivia.value = true
        viewModelScope.launch {
            val result = com.example.data.ai.GeminiAiService.getQuickTrivia(
                mediaTitle = mediaItem.title,
                category = mediaItem.category.displayName
            )
            _isLoadingTrivia.value = false
            result.onSuccess { list ->
                _triviaList.value = list
            }.onFailure {
                _triviaList.value = emptyList()
            }
        }
    }

    fun generateAiPoster(prompt: String, style: String = "Cyberpunk Cinematic Neon", aspectRatio: String = "9:16") {
        if (prompt.isBlank()) return
        _isGeneratingPoster.value = true
        _generatedPoster.value = null
        viewModelScope.launch {
            val result = com.example.data.ai.GeminiAiService.generatePoster(
                prompt = prompt,
                style = style,
                aspectRatio = aspectRatio
            )
            _isGeneratingPoster.value = false
            result.onSuccess { poster ->
                _generatedPoster.value = poster
                showToast("Poster Generated Successfully!")
            }.onFailure { err ->
                showToast("Poster Gen: ${err.message ?: "Generation failed"}")
            }
        }
    }

    fun openAiStudioForMedia(mediaItem: MediaItem) {
        _selectedMediaItem.value = mediaItem
        fetchMediaTrivia(mediaItem)
        navigateTo(AppNavScreen.AI_STUDIO)
    }

    fun setGeminiApiKey(key: String) {
        com.example.data.ai.GeminiAiService.setApiKey(key)
        showToast("Gemini API Key Updated!")
    }

    fun isGeminiKeyConfigured(): Boolean {
        return com.example.data.ai.GeminiAiService.isKeyConfigured()
    }
}
