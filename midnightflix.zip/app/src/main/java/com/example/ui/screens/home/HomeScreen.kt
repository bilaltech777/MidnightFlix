package com.example.ui.screens.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaCategory
import com.example.data.model.MediaItem
import com.example.ui.components.HeroBannerCarousel
import com.example.ui.components.MediaPosterCard
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.MidnightBlack
import com.example.ui.theme.MidnightCardBg
import com.example.ui.theme.MidnightCardStroke
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VipGold
import com.example.ui.viewmodel.AppNavScreen
import com.example.ui.viewmodel.MidnightFlixViewModel

@Composable
fun HomeScreen(
    viewModel: MidnightFlixViewModel,
    modifier: Modifier = Modifier
) {
    val userProfile by viewModel.userProfile.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val allMedia = remember { viewModel.mediaRepository.getAllMedia() }
    val featured = remember { viewModel.mediaRepository.getFeatured() }
    val trending = remember { viewModel.mediaRepository.getTrending() }
    val animeList = remember { viewModel.mediaRepository.getMediaByCategory(MediaCategory.ANIME) }
    val midnightList = remember { viewModel.mediaRepository.getMidnightExclusives() }
    val seriesList = remember { viewModel.mediaRepository.getMediaByCategory(MediaCategory.SERIES) }
    val moviesList = remember { viewModel.mediaRepository.getMediaByCategory(MediaCategory.MOVIE) }

    // Live search filter for home screen
    val searchFilteredMedia = remember(searchQuery, allMedia) {
        if (searchQuery.isBlank()) {
            emptyList()
        } else {
            viewModel.mediaRepository.searchMedia(searchQuery)
        }
    }

    val isSearchActive = searchQuery.isNotBlank()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBlack)
            .testTag("home_screen"),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // App Top Bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Logo & Title
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(
                                Color(0xFFD0BCFF),
                                RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Logo",
                            tint = Color(0xFF381E72),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "CINEVERSE",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "ULTRA",
                                color = Color(0xFFD0BCFF),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                        }
                        Text(
                            text = "480p Free • 720p/1080p VIP",
                            color = Color(0xFFCAC4D0),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // VIP Pass Upgrade Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            if (userProfile.isOwner)
                                Color(0xFFD0BCFF)
                            else
                                Color(0xFF2B2930)
                        )
                        .border(
                            1.dp,
                            if (userProfile.isOwner) Color(0xFFD0BCFF) else Color(0xFF49454F),
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { viewModel.openVipDialog() }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.WorkspacePremium,
                            contentDescription = "VIP",
                            tint = if (userProfile.isOwner) Color(0xFF381E72) else Color(0xFFD0BCFF),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (userProfile.isOwner) "VIP OWNER" else "UPGRADE",
                            color = if (userProfile.isOwner) Color(0xFF381E72) else Color(0xFFD0BCFF),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // CineAI Cinema Intelligence Studio Spotlight Banner
        item {
            Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            androidx.compose.ui.graphics.Brush.horizontalGradient(
                                listOf(
                                    Color(0xFF2B1647),
                                    Color(0xFF1B1430),
                                    Color(0xFF141324)
                                )
                            )
                        )
                        .border(1.dp, Color(0xFF9D65C9).copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .clickable { viewModel.navigateTo(AppNavScreen.AI_STUDIO) }
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    tint = Color(0xFFD0BCFF),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "NEW • GEMINI 3.5 POWERED",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFD0BCFF),
                                    letterSpacing = 1.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "CineAI Cinema Studio",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Chat with AI film concierge, run deep High-Thinking director breakdowns, & generate custom AI posters.",
                                fontSize = 11.sp,
                                color = TextSecondary,
                                lineHeight = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color(0xFFD0BCFF))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "Open AI",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF381E72)
                            )
                        }
                    }
                }
            }

        // Search Bar at Top of Home Screen
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = {
                        Text(
                            text = "Search movies, anime & shows by title...",
                            color = TextMuted,
                            fontSize = 13.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search icon",
                            tint = Color(0xFFD0BCFF),
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = { viewModel.setSearchQuery("") },
                                modifier = Modifier.testTag("home_search_clear_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear search",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("home_search_bar"),
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF1C1B1F),
                        unfocusedContainerColor = Color(0xFF1C1B1F),
                        focusedBorderColor = Color(0xFFD0BCFF),
                        unfocusedBorderColor = MidnightCardStroke,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                // Quick Popular Search Suggestions Chips
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val popularSearches = listOf(
                        "Solo Leveling",
                        "Demon Slayer",
                        "Mirzapur",
                        "Oppenheimer",
                        "Midnight Shadows",
                        "Stranger Realities",
                        "Interstellar",
                        "The Boys"
                    )

                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(end = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.TrendingUp,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "Quick:",
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    items(popularSearches) { titleQuery ->
                        val isSelected = searchQuery.equals(titleQuery, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) Color(0xFFD0BCFF) else Color(0xFF1C1B1F))
                                .border(
                                    1.dp,
                                    if (isSelected) Color(0xFFD0BCFF) else Color(0xFF49454F).copy(alpha = 0.5f),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    if (isSelected) {
                                        viewModel.setSearchQuery("")
                                    } else {
                                        viewModel.setSearchQuery(titleQuery)
                                    }
                                }
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = titleQuery,
                                color = if (isSelected) Color(0xFF381E72) else Color(0xFFCAC4D0),
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        // If user is searching: display dynamic Search Results section
        if (isSearchActive) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Search Results",
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${searchFilteredMedia.size} titles found for \"$searchQuery\"",
                            color = Color(0xFFD0BCFF),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Text(
                        text = "Clear",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF2B2930))
                            .clickable { viewModel.setSearchQuery("") }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            if (searchFilteredMedia.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp, horizontal = 24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "No titles found for \"$searchQuery\"",
                                color = TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Try searching by genre, cast, or another movie title",
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            } else {
                // Display search matches in rows of 2 or full horizontal rows
                val chunkedMatches = searchFilteredMedia.chunked(2)
                items(chunkedMatches) { rowItems ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        for (item in rowItems) {
                            Box(modifier = Modifier.weight(1f)) {
                                MediaPosterCard(
                                    mediaItem = item,
                                    onClick = { viewModel.playMedia(item) },
                                    onQuickPlay = { viewModel.playMedia(item) },
                                    onDownloadClick = { viewModel.openDownloadDialog(item) },
                                    cardWidth = 170.dp,
                                    cardHeight = 230.dp
                                )
                            }
                        }
                        // Fill space if row has only 1 item
                        if (rowItems.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        } else {
            // Default Home Feed Content (When search is inactive)

            // Hero Banner Carousel
            item {
                HeroBannerCarousel(
                    featuredItems = featured,
                    onItemClick = { viewModel.openMediaDetails(it) },
                    onPlayClick = { viewModel.playMedia(it) },
                    onDownloadClick = { viewModel.openDownloadDialog(it) }
                )
            }

            // Category Quick Filter Bar
            item {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val categories = listOf(
                        Pair("All Catalog", MediaCategory.ALL),
                        Pair("Movies", MediaCategory.MOVIE),
                        Pair("Anime Universe", MediaCategory.ANIME),
                        Pair("Midnight Shows (18+)", MediaCategory.MIDNIGHT),
                        Pair("Web Series", MediaCategory.SERIES)
                    )

                    items(categories) { (label, cat) ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(MidnightCardBg)
                                .border(1.dp, MidnightCardStroke, RoundedCornerShape(20.dp))
                                .clickable {
                                    viewModel.selectCategory(cat)
                                    viewModel.navigateTo(AppNavScreen.EXPLORE)
                                }
                                .padding(horizontal = 14.dp, vertical = 7.dp)
                        ) {
                            Text(
                                text = label,
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // CineAI Cinema Intelligence Studio Spotlight Banner
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            androidx.compose.ui.graphics.Brush.horizontalGradient(
                                listOf(
                                    Color(0xFF2B1647),
                                    Color(0xFF1B1430),
                                    Color(0xFF141324)
                                )
                            )
                        )
                        .border(1.dp, Color(0xFF9D65C9).copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .clickable { viewModel.navigateTo(AppNavScreen.AI_STUDIO) }
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    tint = Color(0xFFD0BCFF),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "GEMINI 3.5 POWERED",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFD0BCFF),
                                    letterSpacing = 1.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "CineAI Studio & Fan Posters",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "AI film concierge, High-Thinking director breakdowns & 4K poster generation.",
                                fontSize = 11.sp,
                                color = TextSecondary,
                                lineHeight = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color(0xFFD0BCFF))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "Open AI",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF381E72)
                            )
                        }
                    }
                }
            }

            // Tier Indicator Banner
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1C1B1F))
                        .border(
                            1.dp,
                            MidnightCardStroke,
                            RoundedCornerShape(16.dp)
                        )
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(Color(0xFF2B2930), CircleShape)
                                    .border(1.dp, Color(0xFF49454F), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (userProfile.isOwner) Icons.Default.Star else Icons.Default.WorkspacePremium,
                                    contentDescription = null,
                                    tint = if (userProfile.isOwner) VipGold else Color(0xFFD0BCFF),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = if (userProfile.isOwner)
                                        "Owner VIP Active (bilalkhatri386@gmail.com)"
                                    else
                                        "Free Tier: Unlimited 480p Streaming",
                                    color = TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (userProfile.isOwner)
                                        "Unlimited 1080p Full HD & 4K Cinema Unlocked"
                                    else
                                        "Upgrade to VIP for 720p HD & 1080p Ultra Downloads",
                                    color = if (userProfile.isOwner) VipGold else TextSecondary,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (userProfile.isOwner) Color(0xFF381E72) else Color(0xFFD0BCFF)
                                )
                                .clickable { viewModel.openVipDialog() }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (userProfile.isOwner) "VIP ACTIVE" else "UPGRADE",
                                color = if (userProfile.isOwner) Color(0xFFD0BCFF) else Color(0xFF381E72),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Section 1: Trending Now
            item {
                SectionHeader(
                    title = "Trending Now",
                    subtitle = "Most watched blockbusters & shows",
                    onSeeAll = {
                        viewModel.selectCategory(MediaCategory.ALL)
                        viewModel.navigateTo(AppNavScreen.EXPLORE)
                    }
                )
                HorizontalMediaRow(
                    items = trending,
                    onItemClick = { viewModel.playMedia(it) },
                    onQuickPlay = { viewModel.playMedia(it) },
                    onDownloadClick = { viewModel.openDownloadDialog(it) }
                )
            }

            // Section 2: Midnight Shows (Late Night 18+ Specials)
            item {
                SectionHeader(
                    title = "Midnight Shows (Exclusive 18+)",
                    subtitle = "Late night psychological thrillers & suspense",
                    accentColor = NeonViolet,
                    onSeeAll = { viewModel.navigateTo(AppNavScreen.MIDNIGHT_HUB) }
                )
                HorizontalMediaRow(
                    items = midnightList,
                    onItemClick = { viewModel.playMedia(it) },
                    onQuickPlay = { viewModel.playMedia(it) },
                    onDownloadClick = { viewModel.openDownloadDialog(it) }
                )
            }

            // Section 3: Anime Universe
            item {
                SectionHeader(
                    title = "Anime Universe (Hindi / Japanese Dub)",
                    subtitle = "Solo Leveling, Jujutsu Kaisen, Demon Slayer",
                    accentColor = Color(0xFFFF007F),
                    onSeeAll = {
                        viewModel.selectCategory(MediaCategory.ANIME)
                        viewModel.navigateTo(AppNavScreen.EXPLORE)
                    }
                )
                HorizontalMediaRow(
                    items = animeList,
                    onItemClick = { viewModel.playMedia(it) },
                    onQuickPlay = { viewModel.playMedia(it) },
                    onDownloadClick = { viewModel.openDownloadDialog(it) }
                )
            }

            // Section 4: Top Web Series
            item {
                SectionHeader(
                    title = "Top Web Series & Sagas",
                    subtitle = "Mirzapur S3, Stranger Realities & The Boys",
                    accentColor = VipGold,
                    onSeeAll = {
                        viewModel.selectCategory(MediaCategory.SERIES)
                        viewModel.navigateTo(AppNavScreen.EXPLORE)
                    }
                )
                HorizontalMediaRow(
                    items = seriesList,
                    onItemClick = { viewModel.playMedia(it) },
                    onQuickPlay = { viewModel.playMedia(it) },
                    onDownloadClick = { viewModel.openDownloadDialog(it) }
                )
            }

            // Section 5: Blockbuster Movies
            item {
                SectionHeader(
                    title = "Blockbuster Movies",
                    subtitle = "Hollywood, Bollywood & Sci-Fi Epics",
                    accentColor = ElectricCyan,
                    onSeeAll = {
                        viewModel.selectCategory(MediaCategory.MOVIE)
                        viewModel.navigateTo(AppNavScreen.EXPLORE)
                    }
                )
                HorizontalMediaRow(
                    items = moviesList,
                    onItemClick = { viewModel.playMedia(it) },
                    onQuickPlay = { viewModel.playMedia(it) },
                    onDownloadClick = { viewModel.openDownloadDialog(it) }
                )
            }
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String,
    onSeeAll: () -> Unit,
    accentColor: Color = Color(0xFFD0BCFF),
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(width = 3.dp, height = 14.dp)
                        .background(accentColor, RoundedCornerShape(2.dp))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = subtitle,
                color = TextMuted,
                fontSize = 11.sp
            )
        }

        Text(
            text = "See All",
            color = Color(0xFFD0BCFF),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.clickable(onClick = onSeeAll)
        )
    }
}

@Composable
fun HorizontalMediaRow(
    items: List<MediaItem>,
    onItemClick: (MediaItem) -> Unit,
    onQuickPlay: (MediaItem) -> Unit,
    onDownloadClick: (MediaItem) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyRow(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(items) { item ->
            MediaPosterCard(
                mediaItem = item,
                onClick = { onItemClick(item) },
                onQuickPlay = { onQuickPlay(item) },
                onDownloadClick = { onDownloadClick(item) }
            )
        }
    }
}
