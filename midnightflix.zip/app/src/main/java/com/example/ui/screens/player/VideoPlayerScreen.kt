package com.example.ui.screens.player

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VideoQuality
import com.example.ui.components.ExoVideoSurface
import com.example.ui.components.QualityBadge
import com.example.ui.theme.MidnightBlack
import com.example.ui.theme.MidnightCardStroke
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppNavScreen
import com.example.ui.viewmodel.MidnightFlixViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoPlayerScreen(
    viewModel: MidnightFlixViewModel,
    onEnterPiP: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val playerState by viewModel.playerState.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()

    val mediaItem = playerState.mediaItem ?: return
    val episode = playerState.selectedEpisode

    var showQualityDropdown by remember { mutableStateOf(false) }
    var showAudioDropdown by remember { mutableStateOf(false) }
    var showSubtitleDropdown by remember { mutableStateOf(false) }
    var showSpeedDropdown by remember { mutableStateOf(false) }
    var showEpisodeSheet by remember { mutableStateOf(false) }

    // Auto-hide controls after 4.5 seconds of user inactivity when playing
    LaunchedEffect(playerState.isControlsVisible, playerState.isPlaying) {
        if (playerState.isControlsVisible && playerState.isPlaying) {
            delay(4500)
            viewModel.toggleControlsVisibility()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBlack)
            .testTag("video_player_screen")
    ) {
        // Hardware-Accelerated ExoPlayer Video Surface
        ExoVideoSurface(
            playerState = playerState,
            onPositionUpdate = { newPos -> viewModel.updatePlayerPosition(newPos) },
            onDurationUpdate = { newDur -> viewModel.setPlayerDuration(newDur) },
            onBufferingChange = { isBuffering -> viewModel.setBuffering(isBuffering) },
            onPlayerError = { err -> viewModel.setPlayerError(err) },
            onPlaybackEnded = { viewModel.playNextEpisode() },
            onToggleControls = { viewModel.toggleControlsVisibility() },
            onDoubleTapSeek = { offset -> viewModel.skipTime(offset) },
            modifier = Modifier.fillMaxSize()
        )

        // Error State Overlay if network/playback fails
        if (playerState.errorMessage != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1B1F)),
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .border(1.dp, Color(0xFF49454F), RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.WifiOff,
                            contentDescription = null,
                            tint = Color(0xFFD0BCFF),
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Playback Interrupted",
                            color = Color(0xFFE2E2E6),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = playerState.errorMessage ?: "Stream buffer timeout. Retrying connection...",
                            color = Color(0xFFCAC4D0),
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { viewModel.retryPlayback() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFD0BCFF),
                                    contentColor = Color(0xFF381E72)
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Retry Stream", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Button(
                                onClick = { viewModel.switchQuality(VideoQuality.P480) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF2B2930),
                                    contentColor = Color(0xFFE2E2E6)
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Use 480p", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Ambient Top/Bottom Gradient Scrims & Controls Overlay
        AnimatedVisibility(
            visible = playerState.isControlsVisible,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = 0.8f),
                                Color.Transparent,
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.85f)
                            )
                        )
                    )
            ) {
                // Top Action Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            viewModel.navigateTo(AppNavScreen.HOME)
                        },
                        modifier = Modifier.testTag("player_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = mediaItem.title,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        if (episode != null) {
                            Text(
                                text = "EP ${episode.episodeNumber}: ${episode.title}",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                maxLines = 1
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        QualityBadge(quality = playerState.currentQuality)

                        Spacer(modifier = Modifier.width(4.dp))

                        // CineAI Studio & Trivia shortcut
                        IconButton(
                            onClick = {
                                viewModel.openAiStudioForMedia(mediaItem)
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "CineAI Cinema Assistant",
                                tint = Color(0xFFD0BCFF),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Resize mode toggle
                        IconButton(
                            onClick = {
                                val nextMode = (playerState.resizeMode + 1) % 3
                                viewModel.setResizeMode(nextMode)
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.AspectRatio,
                                contentDescription = "Aspect Ratio",
                                tint = Color(0xFFD0BCFF),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Playback Speed dropdown
                        Box {
                            IconButton(onClick = { showSpeedDropdown = true }) {
                                Icon(
                                    imageVector = Icons.Default.Speed,
                                    contentDescription = "Speed",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            DropdownMenu(
                                expanded = showSpeedDropdown,
                                onDismissRequest = { showSpeedDropdown = false },
                                modifier = Modifier.background(Color(0xFF1C1B1F))
                            ) {
                                listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { speed ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = "${speed}x",
                                                color = if (playerState.playbackSpeed == speed) Color(0xFFD0BCFF) else Color(0xFFE2E2E6),
                                                fontWeight = if (playerState.playbackSpeed == speed) FontWeight.Bold else FontWeight.Normal,
                                                fontSize = 12.sp
                                            )
                                        },
                                        onClick = {
                                            showSpeedDropdown = false
                                            viewModel.setPlaybackSpeed(speed)
                                        }
                                    )
                                }
                            }
                        }

                        if (mediaItem.episodes.isNotEmpty()) {
                            IconButton(onClick = { showEpisodeSheet = true }) {
                                Icon(Icons.Default.VideoLibrary, contentDescription = "Episodes", tint = Color.White, modifier = Modifier.size(20.dp))
                            }
                        }

                        // Picture in Picture button
                        IconButton(
                            onClick = onEnterPiP,
                            modifier = Modifier.testTag("pip_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureInPictureAlt,
                                contentDescription = "Picture in Picture",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Center Transport Controls (Rewind 10s, Play/Pause, Forward 10s)
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(28.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.skipTime(-10) },
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color.Black.copy(alpha = 0.65f), CircleShape)
                            .border(1.dp, Color(0xFF49454F).copy(alpha = 0.6f), CircleShape)
                            .testTag("player_rewind_10s_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Replay10,
                            contentDescription = "Rewind 10s",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    IconButton(
                        onClick = { viewModel.togglePlayPause() },
                        modifier = Modifier
                            .size(68.dp)
                            .background(Color(0xFFD0BCFF), CircleShape)
                            .testTag("player_play_pause_button")
                    ) {
                        Icon(
                            imageVector = if (playerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = Color(0xFF381E72),
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    IconButton(
                        onClick = { viewModel.skipTime(10) },
                        modifier = Modifier
                            .size(52.dp)
                            .background(Color.Black.copy(alpha = 0.65f), CircleShape)
                            .border(1.dp, Color(0xFF49454F).copy(alpha = 0.6f), CircleShape)
                            .testTag("player_forward_10s_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Forward10,
                            contentDescription = "Forward 10s",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                // Bottom Controls & Scrub Bar
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    // Time Progress Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = formatTime(playerState.currentPositionSeconds),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = formatTime(playerState.totalDurationSeconds),
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    // Scrubber Slider
                    Slider(
                        value = playerState.currentPositionSeconds.toFloat().coerceIn(0f, (if (playerState.totalDurationSeconds > 0) playerState.totalDurationSeconds else 7200L).toFloat()),
                        onValueChange = { viewModel.updatePlayerPosition(it.toLong()) },
                        valueRange = 0f..(if (playerState.totalDurationSeconds > 0) playerState.totalDurationSeconds else 7200L).toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFD0BCFF),
                            activeTrackColor = Color(0xFFD0BCFF),
                            inactiveTrackColor = Color(0xFF49454F)
                        ),
                        modifier = Modifier
                            .height(24.dp)
                            .testTag("player_timeline_slider")
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Buttons Bar: Quality, Audio, Subtitles, Mute, Download
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Quality Selector Button
                        Box {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF1C1B1F))
                                    .border(1.dp, Color(0xFF49454F), RoundedCornerShape(8.dp))
                                    .clickable { showQualityDropdown = true }
                                    .padding(horizontal = 8.dp, vertical = 5.dp)
                                    .testTag("player_quality_selector"),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.HighQuality, contentDescription = null, tint = Color(0xFFD0BCFF), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${playerState.currentQuality.label} (${if (playerState.currentQuality.isFree) "Free" else "VIP"})",
                                    color = Color(0xFFE2E2E6),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            DropdownMenu(
                                expanded = showQualityDropdown,
                                onDismissRequest = { showQualityDropdown = false },
                                modifier = Modifier.background(Color(0xFF1C1B1F))
                            ) {
                                listOf(VideoQuality.P480, VideoQuality.P720, VideoQuality.P1080, VideoQuality.P4K).forEach { q ->
                                    val hasAccess = userProfile.canAccessQuality(q)
                                    DropdownMenuItem(
                                        text = {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "${q.label} • ${q.resolutionText}",
                                                    color = if (playerState.currentQuality == q) Color(0xFFD0BCFF) else Color(0xFFE2E2E6),
                                                    fontSize = 12.sp,
                                                    fontWeight = if (playerState.currentQuality == q) FontWeight.Bold else FontWeight.Normal
                                                )
                                                if (q.isFree) {
                                                    Text(" (FREE)", color = Color(0xFFCAC4D0), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                } else if (!hasAccess) {
                                                    Icon(Icons.Default.Lock, contentDescription = "VIP", tint = Color(0xFFD0BCFF), modifier = Modifier.size(14.dp))
                                                }
                                            }
                                        },
                                        onClick = {
                                            showQualityDropdown = false
                                            viewModel.switchQuality(q)
                                        }
                                    )
                                }
                            }
                        }

                        // Audio Selector Button
                        Box {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF1C1B1F))
                                    .border(1.dp, Color(0xFF49454F), RoundedCornerShape(8.dp))
                                    .clickable { showAudioDropdown = true }
                                    .padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Audiotrack, contentDescription = null, tint = Color(0xFFD0BCFF), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(playerState.audioLanguage, color = Color(0xFFE2E2E6), fontSize = 11.sp)
                            }

                            DropdownMenu(
                                expanded = showAudioDropdown,
                                onDismissRequest = { showAudioDropdown = false },
                                modifier = Modifier.background(Color(0xFF1C1B1F))
                            ) {
                                mediaItem.audioLanguages.forEach { lang ->
                                    DropdownMenuItem(
                                        text = { Text(lang, color = Color(0xFFE2E2E6), fontSize = 12.sp) },
                                        onClick = {
                                            showAudioDropdown = false
                                            viewModel.setAudioLanguage(lang)
                                        }
                                    )
                                }
                            }
                        }

                        // Subtitle Selector Button
                        Box {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF1C1B1F))
                                    .border(1.dp, Color(0xFF49454F), RoundedCornerShape(8.dp))
                                    .clickable { showSubtitleDropdown = true }
                                    .padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.ClosedCaption, contentDescription = null, tint = TextMuted, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(playerState.subtitleLanguage, color = Color(0xFFE2E2E6), fontSize = 11.sp)
                            }

                            DropdownMenu(
                                expanded = showSubtitleDropdown,
                                onDismissRequest = { showSubtitleDropdown = false },
                                modifier = Modifier.background(Color(0xFF1C1B1F))
                            ) {
                                listOf("English", "Hindi", "Japanese", "Off").forEach { sub ->
                                    DropdownMenuItem(
                                        text = { Text(sub, color = Color(0xFFE2E2E6), fontSize = 12.sp) },
                                        onClick = {
                                            showSubtitleDropdown = false
                                            viewModel.setSubtitleLanguage(sub)
                                        }
                                    )
                                }
                            }
                        }

                        // Mute/Unmute Button
                        IconButton(
                            onClick = { viewModel.toggleMute() },
                            modifier = Modifier
                                .size(34.dp)
                                .background(Color(0xFF1C1B1F), CircleShape)
                                .border(1.dp, Color(0xFF49454F), CircleShape)
                        ) {
                            Icon(
                                imageVector = if (playerState.isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                contentDescription = if (playerState.isMuted) "Unmute" else "Mute",
                                tint = Color(0xFFD0BCFF),
                                modifier = Modifier.size(17.dp)
                            )
                        }

                        // Quick Download Button
                        IconButton(
                            onClick = { viewModel.openDownloadDialog(mediaItem, episode) },
                            modifier = Modifier
                                .size(34.dp)
                                .background(Color(0xFF1C1B1F), CircleShape)
                                .border(1.dp, Color(0xFF49454F), CircleShape)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = "Download", tint = Color(0xFFD0BCFF), modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }

    // Episode Selector Bottom Sheet
    if (showEpisodeSheet && mediaItem.episodes.isNotEmpty()) {
        ModalBottomSheet(
            onDismissRequest = { showEpisodeSheet = false },
            containerColor = Color(0xFF1C1B1F)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "Episodes - ${mediaItem.title}",
                    color = Color(0xFFE2E2E6),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                mediaItem.episodes.forEach { ep ->
                    val isCurrent = episode?.id == ep.id
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isCurrent) Color(0xFF2B2930) else Color(0xFF161618)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .border(1.dp, if (isCurrent) Color(0xFFD0BCFF) else MidnightCardStroke, RoundedCornerShape(12.dp))
                            .clickable {
                                showEpisodeSheet = false
                                viewModel.playMedia(mediaItem, ep, playerState.currentQuality)
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "EP ${ep.episodeNumber}. ${ep.title}",
                                    color = if (isCurrent) Color(0xFFD0BCFF) else Color(0xFFE2E2E6),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${ep.durationMinutes} min",
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            }

                            if (isCurrent) {
                                Text("PLAYING", color = Color(0xFFD0BCFF), fontSize = 10.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

private fun formatTime(totalSeconds: Long): String {
    val mins = totalSeconds / 60
    val secs = totalSeconds % 60
    return String.format("%02d:%02d", mins, secs)
}
