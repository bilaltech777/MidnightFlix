package com.example

import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.DownloadQualityDialog
import com.example.ui.components.VipUpgradeDialog
import com.example.ui.screens.ai.AiStudioScreen
import com.example.ui.screens.details.MediaDetailsScreen
import com.example.ui.screens.downloads.DownloadsScreen
import com.example.ui.screens.explore.ExploreScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.midnight.MidnightScreen
import com.example.ui.screens.player.VideoPlayerScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.theme.CinemaRed
import com.example.ui.theme.ImmersiveOnPrimary
import com.example.ui.theme.ImmersivePrimary
import com.example.ui.theme.ImmersiveSurfaceVariant
import com.example.ui.theme.MidnightBlack
import com.example.ui.theme.MidnightCardStroke
import com.example.ui.theme.MidnightDarkSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VipGold
import com.example.ui.viewmodel.AppNavScreen
import com.example.ui.viewmodel.MidnightFlixViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MidnightFlixViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MidnightFlixApp(
                    viewModel = viewModel,
                    onEnterPiP = { enterPipMode() }
                )
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (viewModel.currentScreen.value == AppNavScreen.VIDEO_PLAYER && viewModel.playerState.value.isPlaying) {
            enterPipMode()
        }
    }

    private fun enterPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val aspectRatio = Rational(16, 9)
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(aspectRatio)
                .build()
            enterPictureInPictureMode(params)
        }
    }
}

@Composable
fun MidnightFlixApp(
    viewModel: MidnightFlixViewModel,
    onEnterPiP: () -> Unit = {}
) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val selectedMedia by viewModel.selectedMediaItem.collectAsState()
    val downloads by viewModel.downloads.collectAsState()
    val showVipUpgradeDialog by viewModel.showVipUpgradeDialog.collectAsState()
    val vipDialogReason by viewModel.vipDialogReason.collectAsState()
    val downloadTargetMedia by viewModel.downloadTargetMedia.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    val activeDownloadingCount = downloads.count { it.status == com.example.data.local.DownloadState.DOWNLOADING }

    // Toast handler
    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    // Handle Back Press
    BackHandler(enabled = currentScreen != AppNavScreen.HOME) {
        when (currentScreen) {
            AppNavScreen.VIDEO_PLAYER -> {
                if (selectedMedia != null) {
                    viewModel.navigateTo(AppNavScreen.MEDIA_DETAILS)
                } else {
                    viewModel.navigateTo(AppNavScreen.HOME)
                }
            }
            AppNavScreen.MEDIA_DETAILS -> viewModel.navigateTo(AppNavScreen.HOME)
            else -> viewModel.navigateTo(AppNavScreen.HOME)
        }
    }

    val isBottomBarVisible = currentScreen !in listOf(AppNavScreen.VIDEO_PLAYER, AppNavScreen.MEDIA_DETAILS)

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MidnightBlack,
        bottomBar = {
            if (isBottomBarVisible) {
                NavigationBar(
                    containerColor = MidnightDarkSurface,
                    contentColor = TextPrimary,
                    tonalElevation = 8.dp,
                    modifier = Modifier
                        .height(70.dp)
                        .border(1.dp, MidnightCardStroke, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                ) {
                    // Home
                    NavigationBarItem(
                        selected = currentScreen == AppNavScreen.HOME,
                        onClick = { viewModel.navigateTo(AppNavScreen.HOME) },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Home", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ImmersivePrimary,
                            selectedTextColor = ImmersivePrimary,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor = ImmersiveSurfaceVariant
                        ),
                        modifier = Modifier.testTag("nav_home")
                    )

                    // Explore
                    NavigationBarItem(
                        selected = currentScreen == AppNavScreen.EXPLORE,
                        onClick = { viewModel.navigateTo(AppNavScreen.EXPLORE) },
                        icon = { Icon(Icons.Default.Explore, contentDescription = "Explore") },
                        label = { Text("Explore", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ImmersivePrimary,
                            selectedTextColor = ImmersivePrimary,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor = ImmersiveSurfaceVariant
                        ),
                        modifier = Modifier.testTag("nav_explore")
                    )

                    // CineAI Studio
                    NavigationBarItem(
                        selected = currentScreen == AppNavScreen.AI_STUDIO,
                        onClick = { viewModel.navigateTo(AppNavScreen.AI_STUDIO) },
                        icon = { Icon(Icons.Default.Star, contentDescription = "CineAI Studio") },
                        label = { Text("CineAI", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ImmersivePrimary,
                            selectedTextColor = ImmersivePrimary,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor = ImmersiveSurfaceVariant
                        ),
                        modifier = Modifier.testTag("nav_ai_studio")
                    )

                    // Downloads
                    NavigationBarItem(
                        selected = currentScreen == AppNavScreen.DOWNLOADS,
                        onClick = { viewModel.navigateTo(AppNavScreen.DOWNLOADS) },
                        icon = {
                            if (activeDownloadingCount > 0) {
                                BadgedBox(
                                    badge = {
                                        Badge(containerColor = ImmersivePrimary, contentColor = ImmersiveOnPrimary) {
                                            Text("$activeDownloadingCount", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = "Downloads")
                                }
                            } else {
                                Icon(Icons.Default.Download, contentDescription = "Downloads")
                            }
                        },
                        label = { Text("Downloads", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ImmersivePrimary,
                            selectedTextColor = ImmersivePrimary,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor = ImmersiveSurfaceVariant
                        ),
                        modifier = Modifier.testTag("nav_downloads")
                    )

                    // Profile / VIP
                    NavigationBarItem(
                        selected = currentScreen == AppNavScreen.PROFILE,
                        onClick = { viewModel.navigateTo(AppNavScreen.PROFILE) },
                        icon = { Icon(Icons.Default.Person, contentDescription = "VIP Pass") },
                        label = { Text(if (userProfile.isOwner) "VIP Pass" else "VIP/Free", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = if (userProfile.isOwner) VipGold else ImmersivePrimary,
                            selectedTextColor = if (userProfile.isOwner) VipGold else ImmersivePrimary,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor = if (userProfile.isOwner) VipGold.copy(alpha = 0.2f) else ImmersiveSurfaceVariant
                        ),
                        modifier = Modifier.testTag("nav_profile")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = if (isBottomBarVisible) innerPadding.calculateBottomPadding() else 0.dp)
        ) {
            when (currentScreen) {
                AppNavScreen.HOME -> HomeScreen(viewModel = viewModel)
                AppNavScreen.EXPLORE -> ExploreScreen(viewModel = viewModel)
                AppNavScreen.MIDNIGHT_HUB -> MidnightScreen(viewModel = viewModel)
                AppNavScreen.AI_STUDIO -> AiStudioScreen(viewModel = viewModel)
                AppNavScreen.DOWNLOADS -> DownloadsScreen(viewModel = viewModel)
                AppNavScreen.PROFILE -> ProfileScreen(viewModel = viewModel)
                AppNavScreen.MEDIA_DETAILS -> {
                    selectedMedia?.let { media ->
                        MediaDetailsScreen(mediaItem = media, viewModel = viewModel)
                    } ?: run {
                        viewModel.navigateTo(AppNavScreen.HOME)
                    }
                }
                AppNavScreen.VIDEO_PLAYER -> VideoPlayerScreen(
                    viewModel = viewModel,
                    onEnterPiP = onEnterPiP
                )
            }
        }
    }

    // Modal: Download Quality Selector
    downloadTargetMedia?.let { (media, episode) ->
        DownloadQualityDialog(
            mediaItem = media,
            episode = episode,
            userProfile = userProfile,
            onQualitySelected = { quality ->
                viewModel.requestDownloadWithQuality(quality)
            },
            onDismiss = { viewModel.closeDownloadDialog() }
        )
    }

    // Modal: VIP Upgrade Dialog
    if (showVipUpgradeDialog) {
        VipUpgradeDialog(
            userProfile = userProfile,
            reasonMessage = vipDialogReason,
            onPlanSelected = { plan ->
                viewModel.upgradePlan(plan)
            },
            onToggleOwnerMode = { enabled ->
                viewModel.toggleOwnerMode(enabled)
            },
            onRedeemCode = { code ->
                viewModel.redeemPromoCode(code)
            },
            onDismiss = { viewModel.closeVipDialog() }
        )
    }
}
