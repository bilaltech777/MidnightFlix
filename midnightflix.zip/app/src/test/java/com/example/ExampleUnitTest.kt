package com.example

import com.example.data.sample.CatalogData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun searchMediaByTitle_returnsMatchingMedia() {
    val query = "solo leveling"
    val matches = CatalogData.allMediaItems.filter {
      it.title.contains(query, ignoreCase = true) || it.hindiTitle.contains(query, ignoreCase = true)
    }
    assertTrue("Search for 'Solo Leveling' should find matching items", matches.isNotEmpty())
    assertEquals("Solo Leveling: Arise", matches.first().title)
  }
}

